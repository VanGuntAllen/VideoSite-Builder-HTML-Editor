<!-- --------------------------------
  Function    :Page Body 2 Properties Tag  
  Description : PageBody  Properties 
 ----------------------------------------------------------------------> 

<div  id="draggable19" >


<div id="template2" style="Z-INDEX: 27; POSITION: absolute;   TOP: 76px; LEFT: 800px;width: 500px;">
 
 
    <div class="row" >
    	<div class="col-md-18">
            <div class="panel with-nav-tabs panel-default">
                <div class="panel-heading">
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab4primary" data-toggle="tab"><i class="fa fa-file-image-o"></i>Page Body</a></li>
                            <li><a href="#tab5primary" data-toggle="tab"><i class="fa fa-map-marker"></i> Page Body Heading 1 & 2</a></li>
                            <li><a href="#tab6primary" data-toggle="tab"><i class="fa fa-file-excel-o"></i>Body Heading 3 & 4</a></li>
                  
                  
                  
                   </ul>
                </div>
                <div class="panel-body">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab4primary">
                     
                     
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">A Warm Welcome!</label>
  <div class="controls">
    <input id="welcome" class="form-control" name="welcome" type="text" value="A Warm Welcome!" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Call to Action Button Text</label>
  <div class="controls">
    <input id="button-text-action" class="form-control" name="button-text-action" type="text" value="Call to Action " class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Call to Action Link URL</label>
  <div class="controls">
    <input id="button-url-action" class="form-control" name="button-url-action" type="text" placeholder="Call to Action Button Link URL" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Text Cantent</label>
  <div class="controls">                     
    <textarea id="heading-text" class="form-control"  name="heading-text"> <P> We have a list of media admin software in the media cloud to customize your web site. You get a Vadeo/Audio site builder , Flash - html5 players generator,instantly publish and manage your videos ,images and pages.</p>            <p>You my buy media tools from us or pay has  needed, just like a phone you only pay when you talk ,you only pay for time yo use . WE will install media site manager has soon! has you buy them , BUY now!  below a list of media ware tools pick one  .</p></textarea>
  </div>
</div>
               
  <!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Video List Section ">Latest Features</label>
  <div class="controls">
    <input class="form-control" id="Latest-Features" name="Latest-Features" type="text" value="Latest Features" class="input-xlarge">
    
  </div>
</div>
                   
                             </div>
                        
                        
                        
                        <div class="tab-pane fade" id="tab5primary">
                        
                                    
           





<label class="control-label" for="textinput"></label>
  <div class="controls">
    <input class="form-control" id="Image-link-URL" name="Image-link-URL" type="text"  value="http://placehold.it/800x500\" class="input-xlarge">
    
  </div>
</di
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Play Media URL</label>
  <div class="controls">
    <input class="form-control" id="Player-link-URL1" name="Player-link-URL1" type="text" value="" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">More Info URL</label>
  <div class="controls">
    <input class="form-control" id="Info-URL" name="Info-URL" type="text" placeholder="More Info URL" class="input-xlarge">
    
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Video List Section ">Feature Label</label>
  <div class="controls">
    <input class="form-control" id="Feature-Label1" name="Feature-Label1" type="text" value="Feature Label" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Media Section Content</label>
  <div class="controls">                     
    <textarea class="form-control" id="Section-textarea" name="Section-textarea"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p></textarea>
  </div>
</div>







<label class="control-label" for="textinput"> Section 2</label>
  <div class="controls">
    <input class="form-control" id="Image-link-URL2" name="Image-link-URL2" type="text"  value="http://placehold.it/800x500\" class="input-xlarge">
    
  </div>
</di
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Play Media URL</label>
  <div class="controls">
    <input class="form-control" id="Player-link-URL2" name="Player-link-URL2" type="text" value="" class="input-xlarge">
    <p class="help-block">help</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">More Info URL</label>
  <div class="controls">
    <input class="form-control" id="Info-URL2" name="Info-URL2" type="text" placeholder="Feature Label" class="input-xlarge">
    
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Video List Section ">Feature Label</label>
  <div class="controls">
    <input class="form-control" id="Feature-Label2" name="Feature-Label2" type="text" value="Feature Label" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Media Section Content</label>
  <div class="controls">  
    <textarea class="form-control" id="Section-textarea2" name="Section-textarea2"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p></textarea>
  </div>
</div>






       </div>
                        
                        
                  
                  
                  
                  
                        
                        <div class="tab-pane fade" id="tab6primary">
                                   
                                   
                          


<label class="control-label" for="textinput"> Section 3</label>
  <div class="controls">
    <input class="form-control" id="Image-link-URL3" name="Image-link-URL3" type="text"  value="http://placehold.it/800x500\" class="input-xlarge">
    
  </div>
</di
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Play Media URL</label>
  <div class="controls">
    <input class="form-control" id="Player-link-URL3" name="Player-link-URL3" type="text" value="" class="input-xlarge">
   
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">More Info URL</label>
  <div class="controls">
    <input class="form-control" id="Info-URL3" name="Info-URL3" type="text" placeholder="More Info URL" class="input-xlarge">
    
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Video List Section ">Feature Label</label>
  <div class="controls">
    <input class="form-control" id="Feature-Label3" name="Feature-Label3" type="text" value="Feature Label" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Media Section Content</label>
  <div class="controls"> 
    <textarea class="form-control" id="Section-textarea3" name="Section-textarea3"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p></textarea>
                    
  </div>
</div>







<label class="control-label" for="textinput"> Section 4</label>
  <div class="controls">
    <input class="form-control" id="Image-link-URL4" name="Image-link-URL4" type="text"  value="http://placehold.it/800x500\" class="input-xlarge">
    
  </div>
</di
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Play Media URL</label>
  <div class="controls">
    <input class="form-control" id="Player-link-URL4" name="Player-link-URL4" type="text" value="" class="input-xlarge">
    <p class="help-block">help</p>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">More Info URL</label>
  <div class="controls">
    <input class="form-control" id="Info-URL4" name="Info-URL4" type="text" placeholder="More-Info-URL" class="input-xlarge">
    
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="Video List Section ">Feature Label</label>
  <div class="controls">
    <input class="form-control" id="Feature-Label4" name="Feature-Label4" type="text" value="Feature Label" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Media Section Content</label>
  <div class="controls">
    <textarea class="form-control" id="Section-textarea4" name="Section-textarea4"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p></textarea>
  </div>
</div>

         
                    
                                   
      
</div>
         <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,4);return  false;" class="btn btn-default">Body Content template#2</button><P><br/>
         <input  class="form-control" onclick="hideBodyTemplate2();return  false;"type="submit" value="Close" class="input-xlarge">
                     
   
                      
                    
             
                             
                        </div> 
                        </div>

                    </div>
                </div>
            </div>
        </div>
	</div>

</div>
 </div>
</div>
 