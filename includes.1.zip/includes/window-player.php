

 <div id="draggable12">
 
<div class="panel panel-default" id="mediaPlayer" style="position: absolute; left:351px;top:262px; Z-INDEX: 210;  display:none;" style="position:absolute;background-color:#FFFFFF;background-image:url();background-repeat:repeat;;background-position:left:351px;top:262px;width:207px;height:85px; border: 2px solid #E68282; border-color: #E68282 #650000 #650000 #9C2828;z-index:200" >	
		
		 <div class="panel-heading" >
                        Window Media Player
                        </div>
            <div class="panel-body">
		<table  width="430" border="0" cellpadding="0" cellspacing="0" style="background-color:#F7F7F7 ; border: 2px solid #FFFFFF; padding: 0px;">
 <tr><td style="padding-bottom: 2px; padding-top: 0px;" width="300">
	<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold; color:#000000;">Insert Video Player:</span>
 <button type="button" class="btn btn-default"  onclick="AddText(this.form,11);return false;" data-toggle="tooltip" title="Window player">
                            <i class="fa fa-windows"></i>
                        </button>

	<BR><BR>
<table class="selectColorBorder" width="380" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 
 <tr>
 
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="80">Video URL:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="300">
	<input type="Text" name="WindowVideoFile" id="media" value=""  Placeholder=" Video URL"   style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  
	 </tr>
</table>
<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold;top: 70px; color:#000000; ">Layout:</span>
<table width="380" border="0" cellpadding="0" cellspacing="0" style="margin-top: 10px;"><tr><td>


<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="100">Alignment:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="playeralignment" id="alignment" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="left">Left</option>
	 <option value="right">Right</option>
	 <option value="texttop">Texttop</option>
	 <option value="absmiddle">Absmiddle</option>
	 <option value="baseline">Baseline</option>
	 <option value="absbottom">Absbottom</option>
	 <option value="bottom">Bottom</option>
	 <option value="middle">Middle</option>
	 <option value="top">Top</option>
	</select>
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Border Thickness:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="border"  Placeholder="Border Thickness"  id="borderThickness" value=""  style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Player id:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="id" id="borderThickness" value=""  Placeholder="Player id"  style="font-size: 10px; width: 100%;"></td>
 </tr>
</table>	

</td>
<td width="10">&nbsp;</td>
<td>


<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #; padding: 0px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="80">Player Width:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="PlayerWidth" id="horizontal" value=""  Placeholder="Playere Width"  style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Player Height:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="PlayerHeight" id="vertical" value=""  Placeholder="Player Height"  style="font-size: 10px; width: 100%;"></td>
 </tr>
</table>	




<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#00000;" width="100">Loop:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="loop"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="true">True</option>
	 <option value="false">False</option>
	 
	</select>
	
	
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;"></td>
 </tr>
 
</table>	

<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px  padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="100">Autostart:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="autostart"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="true">True</option>
	 <option value="false">False</option>
	 
	</select>
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;"></td>
 </tr>
</table>
<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold;top: 180px; color:#00000;">Div Spacing:</span>
<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="80">Top:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="div_widths" id="" value=""  Placeholder="Top" style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Left :</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="div_heights" id="" value=""  Placeholder="Left"  style="font-size: 10px; width: 100%;"></td>

 </tr>
</table>

           
</td></tr>
</table>
             
</td></tr>
</table>
	   

<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 350px;  margin-top: 10px; width: 52px;" onClick="hideMediaPlayer();return false;">Close</button>

</div></div></div>
</div>