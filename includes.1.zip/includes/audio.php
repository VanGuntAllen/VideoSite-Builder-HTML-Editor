








<div id="audioform" >
<div  id="draggable2" class="panel panel-default" style="Z-INDEX: 27; POSITION:  relative; background-color: #F7F7F7;  border: 2px solid #CCCCCC; border-color: #CCCCCC #121212 #121212 #CCCCCC; TOP: 66px; LEFT: 300px; Width:440px">   
      
<div class="panel-heading" >
                        Audio Properties
                        </div>
          
       <div class="panel-body " style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 10px; ">   
       	Insert
<button type="button" class="btn btn-default"  onclick="AddText(this.form,14);return false;" data-toggle="tooltip" title="Insert AudioPlayer">
      <i class="fa fa-music"></i>
                        </button ><br/><br/>
<input class="" type="text" name="audio" value="Audio URL" size="60" /><P>
<input class="" type="text" name="audio_width" value="AudioPlayer Width" size="20" /><P>
<input class="" type="text" name="audio_top" value="Image-Top" size="20" /><P>
<input class="" type="text" name="audio_left" value="Image-Left" size="20" />

 

<br/><br/>
<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 297px; width: 62px;top:0px;" onClick="hideAudioForm();return false;">Close</button>
             <p><br>          
</div></div></div>




         
       

</div>

