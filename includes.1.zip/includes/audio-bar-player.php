
<!--------------------------------------------------------------
  Function    :  Audio Bar Player  Form Properties Tag  
  Description :  Audio Bar Player Form  Properties 
 ----------------------------------------------------------------------> 

<div  id="draggable26">
<div id="audio-form"  class="panel panel-default" style="position: absolute; left:910px;top:162px; Z-INDEX: 220; width: 800px; display:none;">

<div class="panel-heading" >
                     Audio Bar Player  List Template  Properties
                        </div>
          
       <div class="panel-body " style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 10px; ">   
<!-- Form Name -->
<legend>Audio Bar Player From</legend>


  
<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Audio bar file</label>
  <div class="controls">                     
    <textarea id="textarea1"  class="form-control"  name="textarea1">
    <li><a href=\"http://imusicplus.smtvs.com/membersarea/radio-audio/STARMEDIARADIO2.mp3\"><b>StarMedia Radio News</b> </span></a></li>
    <li><a href=\"http://imusicplus.smtvs.com/membersarea/radio-audio/STARMEDIARADIO1.mp3\"><b>StarMedia Radio</b> </span></a></li>
    </textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebutton"></label>
  <div class="controls">
      <input  class="form-control"  onclick="Buildhtml(this.form,19);return  false;" type="submit" value="Insert Audio File" class="input-xlarge">
    <input  class="form-control" onclick="hidewAudioForm();return  false;"type="submit" value="Close" class="input-xlarge">
   
  </div>
</div>



</div>
 </div>
</div>





