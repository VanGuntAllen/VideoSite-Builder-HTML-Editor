  
<!-- --------------------------------
  Function    :Template Controls Properties 
  Description : Template Controls 
 ----------------------------------------------------------------------> 
  
<div  id="draggable17">
<div id="template-properties"  class="panel panel-default" style="position: absolute; left:651px;top:102px; Z-INDEX: 220; width: 400px; display:none;">

 
<div class="panel-heading" >
                      TemplateProperties
                        </div>
          
       <div class="panel-body " style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 10px; ">   
    
<fieldset>

<!-- Form Name -->
<legend><font size="3" face="Arial Baltic"  color="#ffffff" >Templates </font ></legend>

<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"><font size="3" face="Arial Baltic"  color="#ffffff" >MenuBar</font ></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="Buildhtml(this.form,1);return  false;"  class="btn btn-success">MenuBar template#1</button>
    <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,2);return  false;" class="btn btn-danger">MenuBar template#2</button>
  </div>
</div>

<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="Buildhtml(this.form,13);return  false;" class="btn btn-success">MenuBar template#3</button>
    <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,18);return  false;" class="btn btn-danger">MenuBar template#4</button>
  </div>
</div>

<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"><font size="3" face="Arial Baltic"  color="#ffffff" >Body Template</font ></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="showBodyTemplate();return  false;" class="btn btn-success">Page Body Template#1</button>
    <button id="button2id" name="button2id"  onclick="showBodyTemplate2();return  false;"class="btn btn-danger">Page Body Template#2</button>
  </div>
</div>

<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"></label>
  <div class="controls">
    <button id="button1id" name="button1id" onclick="Buildhtml(this.form,14);return  false;" class="btn btn-success">Page Body Template#3</button>
     
    </div>
</div>

<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"><font size="3" face="Arial Baltic"  color="#ffffff" >Style Color</font ></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="AddText(this.form,31);return  false;" class="btn btn-danger">Style Color  #1</button>
    <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,11);return  false;"class="btn btn-success">Style Color  #2</button>
     <button id="singlebutton" name="singlebutton"  onclick="Buildhtml(this.form,12);return  false;"class="btn btn-warning">Style Color  #3</button>

  </div>
</div>


<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"><font size="3" face="Arial Baltic"  color="#ffffff" > Carousel Slider</font ></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="Buildhtml(this.form,15);return  false;"class="btn btn-danger">CarouselSlider#1</button>
      <button id="singlebutton" name="singlebutton"  onclick="Buildhtml(this.form,17);return  false;" class="btn btn-warning">CarouselSlider#3</button>
    <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,16);return  false;"class="btn btn-success"> Marquee </button>

</div>


<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"><font size="3" face="Arial Baltic"  color="#ffffff" >Content template</font ></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="showContentTemplate();return  false;" class="btn btn-danger">Content template</button>
  
  
 
  </div>
</div>



<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="Buildhtml(this.form,9);return  false;"class="btn btn-success">Product template#3</button>
    <button id="button2id" name="button2id"  onclick="showFooter();return  false;" class="btn btn-danger">FooterText  template</button>
  </div>
</div>
<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"><font size="3" face="Arial Baltic"  color="#ffffff" >Video List template</font ></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="Buildhtml(this.form,6);return  false;" class="btn btn-success">Video List template#1</button>
    <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,10);return  false;"class="btn btn-danger">VideoList template#2</button>
  </div>
</div>
<!-- Button (Double) -->
<div class="control-group">
  <label class="control-label" for="button1id"></label>
  <div class="controls">
    <button id="button1id" name="button1id"  onclick="showAudioForm();return  false;"class="btn btn-danger">Audio Bar Player</button>
           	
	       
  </div>
</div>
<!-- Button (Double) -->
  <input  class="form-control" onclick="hideTemplateProperties();return  false;"type="submit" value="Close" class="input-xlarge">
	   
         
</fieldset>
 </div>
</div>
</div>
