        
        	             
<!----------------------------------
  Function    :Menu Bar Properties 
  Description : Menu Bar
 ----------------------------------------------------------------------> 
   
            <div class="panel panel-default" style="Z-INDEX: 27; POSITION: absolute; background-color: #F7F7F7;   TOP: 66px; LEFT: 15px">
                <div class="panel-heading">
                    <div class="btn-group">
                    <a class="tip btn paste-btn"  href=""   data-toggle="tooltip" title="New file"> <i class="fa fa-file-o"></i></i></a>
                       
                        <button type="submit" class="btn btn-default"   name="save_file"  data-toggle="tooltip" title="SaveFile">
                            <i class="fa fa-save"></i>
                        </button>
                        
                        
                        <button type="button" class="btn btn-default"   onClick="printit()" data-toggle="tooltip" title="Print">
                            <i class="fa fa-print"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="hidePageBodyView();showSourceCode(); return false;" title="Source code">
                            <i class="fa fa-code"></i> Source
                        </button>
                         <button type="button" class="btn btn-default" data-toggle="tooltip" onClick="showPageProperties();return false;" title="PageProperties">
                            <i class="fa fa-align-justify"></i>
                        </button>     
                     
			<a class="tip btn paste-btn"  href="#" onclick="showPageBodyView();hideSourceCode(); return false;" title="PageBody"><i class="fa fa-edit"></i></a>
					<a   class="tip btn paste-btn"  href="#" onclick="preview.document.write (document.getElementsByTagName ('TEXTAREA')[0].value); preview.document.close(); preview.focus(); showDesign(); hideSourceCode();return false;" title="Live Preview">  <i class="fa fa-eye"></i></a>
		                        
  <button type="button" class="btn btn-default" onclick="Generate(this.form)"return false;" data-toggle="tooltip" title="Generate Source">
                          <i class="fa fa-gear "> </i>  
                        </button>
              
                     <button class="btn btn-default"   onclick="View(this.form);return false;" Title="Web PreView" >  <i class="fa fa-globe"></i>    </button>

                    
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,4);return false;"title="Bold">
                            <i class="fa fa-bold"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,5);return false;" title="Italic">
                            <i class="fa fa-italic"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,21);return false;" title="Underline">
                            <i class="fa fa-underline"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,8);return false;" title="Line">
                            <i class="fa fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-default"  onclick="AddText(this.form,7);return false;"data-toggle="tooltip" title="Break">
                          Brk
                        </button>
                         <button type="button" class="btn btn-default"  onclick="AddText(this.form,39);return false;"data-toggle="tooltip" title="Heading 1">
                          H1
                        </button>
                        
                         <button type="button" class="btn btn-default"  onclick="AddText(this.form,40);return false;"data-toggle="tooltip" title=" Heading2">
                          H2
                        </button>
                         <button type="button" class="btn btn-default"  onclick="AddText(this.form,41);return false;"data-toggle="tooltip" title="Heading 3">
                          H3
                        </button>
                         <button type="button" class="btn btn-default"  onclick="AddText(this.form,42);return false;"data-toggle="tooltip" title="Heading 4">
                          H4
                        </button>
                        
                         <button type="button" class="btn btn-default"  onclick="AddText(this.form,43);return false;"data-toggle="tooltip" title="Heading 5">
                          H5
                        </button>
                         <button type="button" class="btn btn-default"  onclick="AddText(this.form,44);return false;"data-toggle="tooltip" title="Heading 6">
                          H6
                        </button>
                        
                        <button type="button" class="btn btn-default"  onClick="showDIVfield();return false;"  data-toggle="tooltip" title="DIV">
                            DIV
                        </button>
                        
                    </div>
                   
                    <div class="btn-group">
                 
                      
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,18);return false;"title="Align left">
                            <i class="fa fa-align-left"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,19);return false;"title="Align center">
                            <i class="fa fa-align-center"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,20);return false;" title="Align right">
                            <i class="fa fa-align-right"></i>
                        </button>
                       
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,22);return false;" title="Numbered list">
                            <i class="fa fa-list-ol"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,23);return false;" title="Bulleted list">
                            <i class="fa fa-list-ul"></i>
                        </button>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-default" data-toggle="tooltip"   onClick="showAnchor();return false;" title="Link">
                            <i class="fa fa-link"></i>
                        </button>
                        <button class="btn btn-default" onclick="showFormBuilder();return false;" Title="FormBuilder" >  <i class="fa   fa-trello"></i> </button>
	    
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,3);return false;"  title="Image Gallery">
                            <i class="fa fa-picture-o"></i>
                        </button>
                    </div>
                
                    <div class="btn-group">
                        <button type="button" class="btn btn-default"  data-toggle="tooltip"  onClick="showGraphic();return false;"      title="Picture">
                            <i class="fa fa-picture-o"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onclick="AddText(this.form,13);return false;"title="Table">
                            <i class="fa fa-table"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" title="Font" onClick="showFontForm();return false;" title="Font">
                            <i class="fa fa-font"></i>
                        </button>
                        <button type="button" class="btn btn-default" data-toggle="tooltip" onClick="showVideoForm();return false;" title="HTML5 Video">
                            <i class="fa fa-html5"></i>
                        </button>
                          
                        <button type="button" class="btn btn-default" onclick="showFMediaPlayer();return false;" data-toggle="tooltip" title="Flash player">
                            <i class="fa fa-flash"></i>
                        </button>
                            
                        <button type="button" class="btn btn-default" onclick="showMediaPlayer();return false;" data-toggle="tooltip" title="Window player">
                            <i class="fa fa-windows"></i>
                        </button>
                         <button type="button" class="btn btn-default" data-toggle="tooltip" onClick="showwAudioForm();return false;" title="Audio player">
                            <i class="fa fa-music"></i>
                        </button>
                      
                        </div>  <div class="btn-group">
                  	<button class="btn btn-default" onclick="showFileView();return false;" Title="FileManager" >  <i class="fa fa-file"></i>   </button>
                  	<button class="btn btn-default" onclick="showTemplateProperties();return false;" Title="TemplatePropert Manager" >  <i class="fa fa-list-alt"></i>   </button>
             	
                    </div>
                </div>
   