<!---------------------------------
  Function    : PageProperties
  Description : showPageProperties()
----------------------------------------!>

<div  id="draggable4" >
<div class="panel panel-default"  style="position: absolute;LEFT: 100px; WIDTH: 637px; TOP: 70px; HEIGHT: 790px;Z-INDEX: 120; display:none; " id="pageProperties">
<div class="panel-heading" >
                        Page Properties
                        </div>
            <div class="panel-body"  >
                            
<table width="380" border="0" cellpadding="0" cellspacing="0"  >


 <tr>

  <td style=" POSITION: absolute;LEFT: 38px; padding-bottom: 2px; padding-top: 22px; font-family: arial, verdana, helvetica; font-size: 11px; color:#ffffff;" width="80">Page Title::</td>
	<td style="  POSITION: absolute;LEFT: 147px; padding-bottom: 20px; padding-top: 18px;" HEIGHT: 32px; width="300">
	
	<input class="form-control"  type="text" name="Name" id="Name" value=""  style=" position: absolute;LEFT: 10px; TOP: 6px;font-size: 10px; width: 420px;"></td>
 
 
 <td style="padding-bottom: 2px; padding-top: 0px;" width="300">
 




 <DIV 
style="Z-INDEX: 7; POSITION: absolute; WIDTH: 150px; HEIGHT: 15px; TOP: 100px; LEFT: 253px" 
id=bv_Text6 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face="Times New Roman">Document Type</FONT></DIV>
<SELECT class="btn btn-primary" style="Z-INDEX: 8; POSITION: absolute; WIDTH: 148px; FONT-FAMILY: arial, verdana, helvetica; FONT-SIZE: 11px; TOP: 100px; LEFT: 356px" id="document_type" size=1 name="document_type"> 

  <OPTION  value="-//W3C//HTML 4.01 Transitional//EN">-//W3C//HTML 4.01 Transitional//EN</OPTION> 
	<OPTION value="-//W3C//DTD HTML 4.01 Transitional//EN">-//W3C//DTD HTML 4.01 Transitional//EN</OPTION> 
	<OPTION value="-//W3C//XHML 4.01 Transitional//EN">-//W3C//XHML 4.01 Transitional//EN</OPTION>
	</SELECT>
	
<INPUT  style="Z-INDEX: 9; POSITION: absolute; WIDTH: 356px; FONT-FAMILY:  arial, verdana, helvetica; HEIGHT: 22px; FONT-SIZE: 11px; TOP: 149px; LEFT: 147px" 
id="favortites_icon" name="favortites_icon" type=text> 

<DIV 
style="Z-INDEX: 10; POSITION: absolute; WIDTH: 87px; HEIGHT: 32px; TOP: 149px; LEFT: 37px" 
id=bv_Text7 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face=Arial>Favortites icon:</FONT></DIV>

<DIV 
style="Z-INDEX: 11; POSITION: absolute; WIDTH: 90px; HEIGHT: 16px; TOP: 100px; LEFT: 37px" 
id=bv_Text8 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff
face=Arial>File extension:</FONT></DIV>
<SELECT class="btn btn-primary"
style="Z-INDEX: 12; POSITION: absolute; WIDTH: 62px; FONT-FAMILY: arial, verdana, helvetica; FONT-SIZE: 11px; TOP: 100px; LEFT: 129px" 
id="document_extension" size=1 name="document_extension"> 
<OPTION selected>.html</OPTION> 
  <OPTION>.php</OPTION> 
	<OPTION>.xml</OPTION>
	</SELECT> 

<DIV 
style="Z-INDEX: 13; POSITION: absolute; WIDTH: 150px; HEIGHT: 48px; TOP: 175px; LEFT: 38px" 
id=bv_Text9 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face=Arial><BR>Language<BR>Character Set :</FONT></DIV>
<SELECT class="btn btn-primary" style="Z-INDEX: 14; POSITION: absolute; WIDTH: 156px; FONT-FAMILY: arial, verdana, helvetica; FONT-SIZE: 11px; TOP: 203px; LEFT: 145px" 
id="characterSet" size=1 name="characterSet">
 <OPTION value="ISO-8859-1">ISO-8859-1</OPTION> 
  <OPTION value="ISO-8859-2">ISO-8859-2</OPTION> 
	<OPTION value="UTF-8">UTF-8</OPTION>
	</SELECT>
 </td><td>
 
		  


<DIV 
style="Z-INDEX: 1; POSITION: absolute; WIDTH: 68px; HEIGHT: 11px; TOP: 300px; LEFT: 37px" 
id=bv_Text1 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face=Arial>Color<B>:</B></FONT></DIV>

<INPUT  onClick="showBackgroundColorMenu();return false;"
style="Z-INDEX: 2; POSITION: absolute; WIDTH: 20px; HEIGHT: 20px; TOP: 295px; LEFT: 249px" 
id=ImageButton1 name=ImageButton7 src="link font_files/backcolor.gif" 
type=image> 
<INPUT class="form-control" style="Z-INDEX: 0; POSITION: absolute; WIDTH: 28px; FONT-FAMILY: Courier New; FONT-SIZE: 11px; TOP: 293px; LEFT: 220px"  id="backgroundColorPreview">
		

<INPUT class="form-control" 
style="Z-INDEX: 3; POSITION: absolute; WIDTH: 84px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 293px; LEFT: 133px" 
id="enterBackgroundColor">


<select class="form-control" name="background" id="background" style="Z-INDEX: 4; POSITION: absolute; WIDTH: 354px; FONT-FAMILY: Courier New; HEIGHT: 20px; FONT-SIZE: 11px; TOP: 366px; LEFT: 148px" >
	 <option value="">Page Back ground</option>
	 <option value="http://smtvs.com/bg_image/bg.png">bg</option>
	 <option value="http://smtvs.com/bg_image/bg2.png">bg2</option>
	  <option value="http://smtvs.com/bg_image/bg3.png">bg3</option>
	   <option value="http://smtvs.com/bg_image/bg4.png">bg4</option>
	    <option value="http://smtvs.com/bg_image/bg5.png">bg5</option>
	     <option value="http://smtvs.com/bg_image/bg6.png">bg6</option>
	      <option value="http://smtvs.com/bg_image/bg7.png">bg7</option>
	           <option value="http://smtvs.com/bg_image/bg8.png">bg8</option>
	               
       <option value="">--new line --</option>
   <option value="http://smtvs.com/bg_image/bg6.jpg"> vga bg 1</option>
   <option value="http://smtvs.com/bg_image/bg7.jpg"> vga bg 2</option>
   <option value="http://smtvs.com/bg_image/bg8.jpg"> vga bg 3</option>
   <option value="http://smtvs.com/bg_image/bg9.jpg"> vga bg 4</option>
   <option value="http://smtvs.com/bg_image/bg10.jpg"> vga bg 5</option>
   <option value="http://smtvs.com/bg_image/bg11.jpg"> vga bg 6</option>
   <option value="http://smtvs.com/bg_image/bg12.jpg"> vga bg 7</option>
   
   <option value="http://smtvs.com/bg_image/bg16.jpg"> vga bg 16</option>
   <option value="http://smtvs.com/bg_image/bg17.jpg"> vga bg 17</option>
   <option value="http://smtvs.com/bg_image/bg18.jpg"> vga bg 18</option>
   <option value="http://smtvs.com/bg_image/bg19.jpg"> vga bg 19</option>
   <option value="http://smtvs.com/bg_image/bg20.jpg"> vga bg 20</option>
   <option value="http://smtvs.com/bg_image/bg21.jpg"> vga bg 21</option>
   <option value="">--new line 2--</option>
    <option value="http://smtvs.com/bg_image/Turntable_spinning.jpg">bg Turntable_spinning</option>
   <option value="http://smtvs.com/bg_image/Flaming-Guitar-Wallpaper-music-17264134-1680-1050.jpg">bg Flaming-Guitar</option>
    <option value="http://smtvs.com/bg_image/colors-of-music.jpg">bg colors-of-music-</option>

 <option value="http://smtvs.com/bg_image/Club-Music-Wallpaper-233.jpg">bg Club-Music-</option>

 <option value="http://smtvs.com/bg_image/image2s.jpg">bg2S</option>

 <option value="http://smtvs.com/bg_image/graphics-music-notes-435227.jpg">bg graphics-music-notes</option>

 <option value="http://smtvs.com/bg_image/Piano-Wallpaper-music-24173623-1280-1024.jpg">bg Piano-Wallpaper</option>

 <option value="http://smtvs.com/bg_image/ws_Tape_music_1024x768.jpg">bg ws_Tape_music</option>

 <option value="http://smtvs.com/bg_image/music-equalizer-background.jpg">bg music-equalizer</option>

 <option value="http://smtvs.com/bg_image/graphic-design-music-wallpaper-7329-hd-wallpapers.jpg">bg music-wallpaper</option>
 <option value="http://smtvs.com/bg_image/101954-club-music-creative-music.jpg">bg music-creative</option>

 <option value="http://smtvs.com/bg_image/music-2.jpg">bg music-wall</option>
   <option value="http://smtvs.com/bg_image/bg_bubble.png">bg bubble</option>
   <option value="http://smtvs.com/bg_image/bg15.png"> colors</option>
  </select>
  
 
<DIV 
style="Z-INDEX: 5; POSITION: absolute; WIDTH: 45px; HEIGHT: 11px; TOP: 366px; LEFT: 38px" 
id=bv_Text2 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face=Arial>Image<B>:</B></FONT></DIV>

<DIV 
style="Z-INDEX: 6; POSITION: absolute; WIDTH: 68px; HEIGHT: 16px; TOP: 456px; LEFT: 39px" 
id=bv_Text3 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff
face=Arial>Topmargin:</FONT></DIV>

<DIV 
style="Z-INDEX: 7; POSITION: absolute; WIDTH: 70px; HEIGHT: 16px; TOP: 456px; LEFT: 296px" 
id=bv_Text4 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff
face=Arial>Leftmargin:</FONT></DIV>

<SELECT class="btn btn-primary"
style="Z-INDEX: 8; POSITION: absolute; WIDTH: 50px; FONT-FAMILY: Courier New; FONT-SIZE: 11px; TOP: 455px; LEFT: 123px" 
id="Leftmargin" size=1 name="Leftmargin"> 
<OPTION  selected value="0">0</OPTION> 
<OPTION value="1">1</OPTION> 
  <OPTION value="2">2</OPTION>
	 <OPTION  value="3">3</OPTION>
	 </SELECT> 
	 
	 <SELECT class="btn btn-primary" style="Z-INDEX: 9; POSITION: absolute; WIDTH: 50px; FONT-FAMILY: Courier New; FONT-SIZE: 11px; TOP: 452px; LEFT: 380px" 
id="Topmargin" size=1 name="Topmargin">
<OPTION  selected value="0">0</OPTION> 
<OPTION value="1">1</OPTION> 
  <OPTION value="2">2</OPTION>
	 <OPTION  value="3">3</OPTION>

	 </SELECT> 
<DIV 
style="Z-INDEX: 10; POSITION: absolute; WIDTH: 86px; HEIGHT: 11px; TOP: 270px; LEFT: 35px" 
id=bv_Text7 align=left><FONT style="FONT-SIZE: 13px" color=#ffffff 
face=Arial><B>Background:</B></FONT></DIV></td>
 
 
  <td  style="Z-INDEX: 18; POSITION: absolute; padding-bottom: 29px;   FONT-FAMILY: Courier New; FONT-SIZE: 11px; TOP: -40px; LEFT: 18px">
 
 <INPUT class="form-control" 
style="Z-INDEX: 0; POSITION: absolute; WIDTH: 28px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 612px; LEFT: 190px" 
id="linkColorPreview"> 


<INPUT  onClick="showLinkColorMenu();return false;"
style="Z-INDEX: 1; POSITION: absolute; WIDTH: 20px; HEIGHT: 20px; TOP: 615px; LEFT: 220px" 
id=ImageButton1 name=ImageButton7 src="link%20font_files/backcolor.gif" 
type=image> 


<INPUT class="form-control" 
style="Z-INDEX: 2; POSITION: absolute; WIDTH: 84px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 612px; LEFT: 98px" 
 id="enterLinkColor"> 
<DIV 
style="Z-INDEX: 3; POSITION: absolute; WIDTH: 62px; HEIGHT: 16px; TOP: 577px; LEFT: 21px" 
id=bv_Text5 align=left><FONT style="FONT-SIZE: 13px" color=#ffffff 
face=Arial><B>Links:</B></FONT></DIV>
<DIV 
style="Z-INDEX: 4; POSITION: absolute; WIDTH: 83px; HEIGHT: 16px; TOP: 618px; LEFT: 28px" 
id=bv_Text6 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face=Arial>Link</FONT></DIV>

<DIV 
style="Z-INDEX: 5; POSITION: absolute; WIDTH: 75px; HEIGHT: 16px; TOP: 617px; LEFT: 248px" 
id=bv_Text8 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face=Arial>Active Link</FONT></DIV>
<DIV 
style="Z-INDEX: 6; POSITION: absolute; WIDTH: 70px; HEIGHT: 32px; TOP: 651px; LEFT: 27px" 
id=bv_Text9 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff
face=Arial>Visited Link</FONT></DIV>
 
<INPUT class="form-control" 
style="Z-INDEX: 7; POSITION: absolute; WIDTH: 28px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 613px; LEFT: 402px" 
 id="activelinkColorPreview"> 

<INPUT   onClick="showActiveLinkColorMenu();return false;" 
style="Z-INDEX: 8; POSITION: absolute; WIDTH: 20px; HEIGHT: 20px; TOP: 616px; LEFT: 435px" 
id=ImageButton5 name=ImageButton7 src="link%20font_files/backcolor.gif" 
type=image>

 <INPUT class="form-control" 
style="Z-INDEX: 9; POSITION: absolute; WIDTH: 84px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 613px; LEFT: 309px" 
id="enterActiveLinkColor"> 


<INPUT id="textColorPreview" class="form-control" 
style="Z-INDEX: 10; POSITION: absolute; WIDTH: 28px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 756px; LEFT: 190px" 
id=Editbox5 name=Editbox1> 

<INPUT onClick="showTextColorMenu();return false;"
style="Z-INDEX: 11; POSITION: absolute; WIDTH: 20px; HEIGHT: 20px; TOP: 759px; LEFT: 220px" 
id=ImageButton6 name=ImageButton7 src="link%20font_files/backcolor.gif" 
type=image> 



<INPUT id="enterTextColor" class="form-control" 
style="Z-INDEX: 12; POSITION: absolute; WIDTH: 84px; FONT-FAMILY: Courier New;
 FONT-SIZE: 16px; TOP: 756px; LEFT: 99px" > 

<INPUT class="form-control" 
style="Z-INDEX: 13; POSITION: absolute; WIDTH: 28px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 647px; LEFT: 190px" 
 id="visitedlinkColorPreview">
 
 
 <INPUT onClick="showVisitedLinkColorMenu();return false;"
style="Z-INDEX: 14; POSITION: absolute; WIDTH: 20px; HEIGHT: 20px; TOP: 650px; LEFT: 220px" 
id=ImageButton7 name=ImageButton7 src="link%20font_files/backcolor.gif" 
type=image> 

<INPUT class="form-control" 
style="Z-INDEX: 15; POSITION: absolute; WIDTH: 84px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 647px; LEFT: 99px" 
id="enterVisitedLinkColor"> 

<DIV 
style="Z-INDEX: 16; POSITION: absolute; WIDTH: 124px; HEIGHT: 48px; TOP: 729px; LEFT: 30px" 
id=bv_Text2 align=left><FONT style="FONT-SIZE: 11px" color=#fffff
face=Arial>Font:<BR><BR>TextColor:</FONT></DIV>


<DIV 
style="Z-INDEX: 17; POSITION: absolute; WIDTH: 95px; HEIGHT: 16px; TOP: 718px; LEFT: 328px" 
id=bv_Text3 align=left><FONT style="FONT-SIZE: 11px" color=#ffffff 
face=Arial>Default Size:</FONT></DIV>

<SELECT class="btn btn-primary" 
style="Z-INDEX: 18; POSITION: absolute; WIDTH: 122px; FONT-FAMILY: Courier New; FONT-SIZE: 11px; TOP: 725px; LEFT: 98px" 
name="font_face"  size=1 > 
 
	 <option value="Arial">Arial</option>
	 <option value="Arial Baltic">Arial Baltic</option>
	 <option value="Arial Black">Arial Black</option>
	 <option value="Arial CE">Arial Black</option>
	 <option value="Arial CYR">Arial CYR</option>
	 <option value="BATAVIA">BATAVIA</option>
	 <option value="Belwe Bd BT">Belwe Bd BT</option>
	 <option value="BatangChe">BatangChe</option>
	 <option value="Belwe Lt BT">Belwe Lt BT</option>
	 <option value="Blade Runner Movie Font">Blade Runner Movie Font</option>
	 <option value="Bookman Old Style">Bookman Old Style</option>
	 <option value="Belwe Cn BT">    Belwe Cn BT</option>
<option value="BrowalliaUPC">   BrowalliaUPC</option>
<option value="Belwe Lt BT">    Belwe Lt BT</option>
<option value="Browallia New">  Browallia New</option>
<option value="CASMIRA">CASMIRA</option>
<option value="Calibri ">   Calibri</option>
<option value="Cambria ">   Cambria</option>
<option value="Clarendon Hv BT "> Clarendon Hv BT</option>
<option value="Candy Round BTN">  Candy Round BTN</option>
<option value="ConcursoItalian BTN">  ConcursoItalian BTN</option>
<option value="Clarendon Lt BT "> Clarendon Lt BT</option>
<option value="Clarendon Blk BT "> Clarendon Blk BT</option>
<option value="Candy Round BTN Lt "> Candy Round BTN Lt</option>
<option value="Candara  Candara"> Candara Candara</option>
<option value="Comic Sans MS">  Comic Sans MS</option>
<option value="Consolas "> Consolas</option>
<option value="Constantia "> Constantia</option>
<option value="Corbel  ">Corbel</option>
<option value="CordiaUPC "> CordiaUPC</option>
<option value="Courier New "> Courier New</option>
<option value="Courier New CE "> Courier New CE</option>
<option value="Courier New CYR "> Courier New CYR</option>
<option value="Courier New TUR ">  Courier New TUR</option>
<option value="DFKai-SB "> DFKai-SB</option>
<option value="DaunPenh "> DaunPenh</option>
<option value="David "> David</option>
<option value="DilleniaUPC">  DilleniaUPC</option>
<option value="DokChampa  ">  DokChampa</option>
<option value="Dotum  ">   Dotum</option>
<option value="DotumChe "> DotumChe</option>
<option value="ELEGANCE">   ELEGANCE</option>
<option value="ELLIS  ">   ELLIS</option>
<option value="EXCESS  "> EXCESS</option>
<option value="Ebrima  "> Ebrima</option>
<option value="English157 BT">   English157 BT</option>
<option value="Estrangelo Edessa ">   Estrangelo Edessa</option>
<option value="EucrosiaUPC  ">  EucrosiaUPC</option>
<option value="Euphemia ">  Euphemia</option>
<option value="FangSong   "> FangSong</option>
<option value="Franklin Gothic Medium ">  Franklin Gothic Medium</option>
<option value="FrankRuehl  "> FrankRuehl</option>
<option value="Freehand575 BT   "> Freehand575 BT</option>
<option value="FreesiaUPC ">     FreesiaUPC</option>
<option value="Freehand521 BT">Freehand521 BT</option>
<option value="GENUINE   ">   GENUINE</option>
<option value="Gabriola  ">   Gabriola</option>
<option value="Galeforce BTN ">   Galeforce BTN</option>
<option value="Gautami  ">  Gautami</option>
<option value="Georgia  ">  Georgia</option>
<option value="Galeforce BTN "> Galeforce BTN</option>
<option value="Gautami  "> Gautami</option>
<option value="GrilledCheese BTN Cn ">   GrilledCheese BTN Cn</option>
<option value="GrilledCheese BTN Toasted "> GrilledCheese BTN Toasted</option>
<option value="GrilledCheese BTN Wide Blk "> GrilledCheese BTN Wide Blk</option>
<option value="Gulim  "> Gulim</option>
<option value="GulimChe ">  GulimChe</option>
<option value="Gungsuh  "> Gungsuh</option>
<option value="HELTERSKELTER ">  HELTERSKELTER
<option value="HERMAN  ">  HERMAN</option>
<option value="Hot Mustard BTN  ">  Hot Mustard BTN</option>
<option value="Hot Mustard BTN Poster ">    Hot Mustard BTN Poster</option>
<option value="ISABELLE  "> ISABELLE</option>
<option value="Impact "> Impact</option>

</SELECT> 
<SELECT class="btn btn-primary" 
style="Z-INDEX: 19; POSITION: absolute; WIDTH: 44px; FONT-FAMILY: Courier New; FONT-SIZE: 11px; TOP: 718px; LEFT: 398px" 
id=font_size size=1 name=font_size>
<option value="">Not Set</option>
	 <option value="1">1 </option>
	 <option value="2">2 </option>
	 <option value="3">3 </option>
	 <option value="4">4 </option>
	 <option value="5">5 </option>
	 <option value="6">6 </option>
	 <option value="7">7 </option>
	 <option value="8">8 </option>
	 <option value="9">9 </option>
	 <option value="10">10 </option>
	 <option value="11">11 </option>
	 <option value="12">12 </option>
	 <option value="13">13 </option>
	 <option value="14">14 </option>
	 <option value="15">15 </option>
	 <option value="16">16 </option>
	 <option value="17">17 </option>
	 <option value="18">18 </option>
	 <option value="19">19 </option>
	 <option value="20">20 </option>
	 <option value="21">21 </option>
  <option value="22">22</option>
	 <option value="23">23 </option>
	 <option value="24">24 </option>
	 <option value="25">25 </option>
	 <option value="26">26 </option>
 
	</SELECT> 
<DIV 
style="Z-INDEX: 20; POSITION: absolute; WIDTH: 82px; HEIGHT: 32px; TOP: 693px; LEFT:23px" 
id=bv_Text1 align=left><FONT style="FONT-SIZE: 13px" color=#ffffff 
face=Arial><B>Default Font:</B></FONT></DIV> 


<div id="bv_Text2" style="position:absolute;left:110px;top:790px;width:494px;height:27px;z-index:44;" align="left">


 <button class="btn btn-primary" type="button" value="button" style="  position:absolute;left:280px;font-family: arial, 
 verdana, helvetica; font-size: 10px; " onclick="showMetaTag();hidePageProperties();return false;">MetaTag</button>


 <button class="btn btn-primary" type="button" value="button" style="  position:absolute;left:360px;font-family: arial, 
 verdana, helvetica; font-size: 11px; " onclick="hidePageProperties();return false;">Ok</button>

</div></div>

<P><BR>
</td>
 </tr>
 </table>
 
 </div>
<div style="position: absolute; display:none;" id="backColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table>
		
</div>
	


		 
		 

<div style="position: absolute; display:none;" id="activelinkColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF;  padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table></div>
			
<div style="position: absolute;display:none; " id="visitedlinkColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; ; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table></div>
			
			
			
<div style="position: absolute; display:none;" id="linkColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF;  padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table></div>
			
			
			<div   style="position: absolute;display:none;" id="textColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table>
		
</div>
</div>

<!----------------------------------------------------------------------
  Function    :PageProperties MetaTag
  Description : showPageProperties MetaTag or  hidePageProperties MetaTag
 ----------------------------------------------------------------------!> 


<div class="panel panel-primary"  style="position: absolute;LEFT: 60px; TOP:153px;  right: 0px; HEIGHT: 530px;WIDTH: 697px;Z-INDEX: 120; display:none;" id="metaTag" >
 <div class="panel-heading" >
                        Meta Tag Panel
                        </div>
            <div class="panel-body">
                            <p>Fill in the Meta Tag data here Author,Keyword,Page Description. (25 words or 
less,Page Categories</p>
                        </div>               
 <INPUT class="form-control"
style="Z-INDEX: 1; POSITION: absolute; WIDTH: 384px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 115px; LEFT: 240px" 
id="meta_author" name="meta_author"> 

<TEXTAREA class="form-control" style="Z-INDEX: 2; POSITION: absolute; WIDTH: 385px; FONT-FAMILY: Courier New; HEIGHT: 110px; FONT-SIZE: 16px; TOP: 167px; LEFT: 240px"  cols=34 rows=5 id="meta_keywords" name="meta_keywords"></TEXTAREA> 
<DIV class="panel-body"
style="Z-INDEX: 3; POSITION: absolute; WIDTH: 150px; HEIGHT: 400px; TOP: 61px; LEFT: 83px" 
 align=left><FONT style="FONT-SIZE: 13px" color=#ffffff
face=Arial><BR></DIV>
<DIV 
style="Z-INDEX: 3; POSITION: absolute; WIDTH: 150px; HEIGHT: 400px; TOP: 20px; LEFT: 83px" 
id=bv_Text1 align=left><FONT style="FONT-SIZE: 13px" color=#ffffff
face=Courier New><BR><BR><BR><BR><BR>Author:<BR><BR><BR>Keyword:<BR>(Seperated&nbsp;by 
Commas)<BR><BR><BR><BR><BR> Page Description:<BR><BR>(25 words or 
less<BR><BR><BR><BR>Categories:</FONT></DIV>
<TEXTAREA  class="form-control" style="Z-INDEX: 4; POSITION: absolute; WIDTH: 385px; FONT-FAMILY: Courier New; HEIGHT: 110px; FONT-SIZE: 16px; TOP: 298px; LEFT: 240px"  cols=34 rows=5 id="meta_description" name="meta_description"></TEXTAREA> 
<INPUT class="form-control"
style="Z-INDEX: 0; POSITION: absolute; WIDTH: 387px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 433px; LEFT: 241px" 
id=Categories name="Categories">

 <button type="button" value="button"  class="btn btn-primary" style="  position:absolute;left:580px;TOP: 478px;font-family: arial, verdana, helvetica; font-size: 11px; " onclick="hideMetaTag();showPageProperties();return false;">Ok</button>
     

 </div>

<div>


<!---------  Form -------->
<div id="draggable28">
<div class="panel panel-default" style="position: absolute;left:430px; top:0px;Z-INDEX: 100;  WIDTH: 490px; display:none;" id="form_builder">
	 <div class="panel-heading" >
                        Form field Properties
                        </div>
            <div class="panel-body">

<div class="control-group">
  <label class="control-label" for="Insert Content Section">Fill in Form Properties</label>
  <div class="controls">
    
    <button type="button"  class="btn btn-default" name="" value=""style="font-family: arial, verdana, helvetica; font-size: 9px;width:93; " onClick="Generateform2(this.form);return false;">GenerateForm</button>
	
	<button type="button"   class="btn btn-default" name="" value=""style="font-family: arial, verdana, helvetica; font-size: 9px; color:"  onclick="showFormProperties();return false;">FormProperties</button>
		<button type="button"  class="btn btn-default"  name="" value=""style="font-family: arial, verdana, helvetica; font-size: 9px; width:85 "  onclick="showProp();return false;">InputProperties</button>	
	<button type="button" class="btn btn-default"  name="" value=""  style="font-family: arial, verdana, helvetica; font-size: 9px;  width:82"onclick="showImageProperties();return false;">ImageProperties</button>
	<button type="button"   class="btn btn-default" name="" value=""style="font-family: arial, verdana, helvetica; font-size: 9px; width:93"  onclick="showTextAreaProperties();return false;">TextAreaProperties</button>

    
     </div>
</div>