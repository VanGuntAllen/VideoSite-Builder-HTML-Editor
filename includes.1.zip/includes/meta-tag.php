<!----------------------------------------------------------------------
  Function    :PageProperties MetaTag
  Description : showPageProperties MetaTag or  hidePageProperties MetaTag
 ----------------------------------------------------------------------!> 


<div class="panel panel-primary"  style="position: absolute;LEFT: 60px; TOP:153px;  right: 0px; HEIGHT: 530px;WIDTH: 697px;Z-INDEX: 120;" id="metaTag" >
 <div class="panel-heading" >
                        Meta Tag Panel
                        </div>
            <div class="panel-body">
                            <p>Fill in the Meta Tag data here Author,Keyword,Page Description. (25 words or 
less,Page Categories</p>
                        </div>               
 <INPUT class="form-control"
style="Z-INDEX: 1; POSITION: absolute; WIDTH: 384px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 115px; LEFT: 240px" 
id="meta_author" name="meta_author"> 

<TEXTAREA class="form-control" style="Z-INDEX: 2; POSITION: absolute; WIDTH: 385px; FONT-FAMILY: Courier New; HEIGHT: 110px; FONT-SIZE: 16px; TOP: 167px; LEFT: 240px"  cols=34 rows=5 id="meta_keywords" name="meta_keywords"></TEXTAREA> 
<DIV class="panel-body"
style="Z-INDEX: 3; POSITION: absolute; WIDTH: 150px; HEIGHT: 400px; TOP: 61px; LEFT: 83px" 
 align=left><FONT style="FONT-SIZE: 13px" color=#ffffff
face=Arial><BR></DIV>
<DIV 
style="Z-INDEX: 3; POSITION: absolute; WIDTH: 150px; HEIGHT: 400px; TOP: 20px; LEFT: 83px" 
id=bv_Text1 align=left><FONT style="FONT-SIZE: 13px" color=#ffffff
face=Courier New><BR><BR><BR><BR><BR>Author:<BR><BR><BR>Keyword:<BR>(Seperated&nbsp;by 
Commas)<BR><BR><BR><BR><BR> Page Description:<BR><BR>(25 words or 
less<BR><BR><BR><BR>Categories:</FONT></DIV>
<TEXTAREA  class="form-control" style="Z-INDEX: 4; POSITION: absolute; WIDTH: 385px; FONT-FAMILY: Courier New; HEIGHT: 110px; FONT-SIZE: 16px; TOP: 298px; LEFT: 240px"  cols=34 rows=5 id="meta_description" name="meta_description"></TEXTAREA> 
<INPUT class="form-control"
style="Z-INDEX: 0; POSITION: absolute; WIDTH: 387px; FONT-FAMILY: Courier New; FONT-SIZE: 16px; TOP: 433px; LEFT: 241px" 
id=Categories name="Categories">

 <button type="button" value="button"  class="btn btn-primary" style="  position:absolute;left:580px;TOP: 478px;font-family: arial, verdana, helvetica; font-size: 11px; " onclick="hideMetaTag();showPageProperties();return false;">Ok</button>
     

 </div>

<div>

