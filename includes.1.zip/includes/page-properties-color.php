<div style="position: absolute; " id="backColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBackColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectBackColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table>
		
</div>
	


		 
		 

<div style="position: absolute; " id="activelinkColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewActiveLinkColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectActiveLinkColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table></div>
			
<div style="position: absolute; " id="visitedlinkColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewVisitedLinkColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectVisitedLinkColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table></div>
			
			
			
<div style="position: absolute; " id="linkColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewLinkColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectLinkColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table></div>
			
			
			<div   style="position: absolute;" id="textColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF; padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewTextColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectTextColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table>
		
</div>
</div>

