
 <div class="col-lg-6"  id="draggable11"      >
                    <div class="panel panel-default" id="fileview" style="Z-INDEX: 40; POSITION: absolute; display:none; background-color: #F7F7F7;  width: 1200px;  display:none;  TOP: 66px; LEFT: 95px">
                        <div class="panel-heading">
                           File Manager is draggable
                        </div>
                        <div class="panel-body"   style="background-color: #F7F7F7;   >
                            <div class="table-responsive">

<table border="1" width="1938.0" cellspacing="0" cellpadding="0" class="t1">
          <tbody>
          <tr>
          
               
 

  <td valign="top" class="td2">
                <p class="p3"><span class="s1"><b>Format</b></span></p>
              </td>
              
              <td valign="top" class="td3">
                <p class="p3"><span class="s1"><b>Edit</b></span></p>
              </td>
              
              <td valign="top" class="td3">
                <p class="p3"><span class="s1"><b>View</b></span></p>
              </td>
              <td valign="top" class="td3">
                <p class="p3"><span class="s1"><b>Delete</b></span></p>
              </td>           
<?php 
            
						 $files = glob("*.html");
            foreach ($files as $file) { if (!is_dir($file)) {?>
   
                 <tr>
              <td valign="top" class="td4">
                <p class="p3"><span class="s1">  <span> <a href="video-builder-cms-v3.php?f=<?php echo $file; ?>">
              <span class="glyphicon glyphicon-file"></span>html
                
                </a></span>
              </td>
              
              <td valign="top" class="td5">
                <p class="p4"><span class="s1" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif, margin-left: 2px; width: 98px;"> 
                <a href="video-builder-cms-v3.php?f=<?php echo $file; ?>">     <span class="glyphicon glyphicon-edit"></span><?php echo basename($file); ?>"</span></p></a>
              </td> 
              
                <td valign="top" class="td4">
                <p class="p3"><span class="s1" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif, margin-left: 2px; width: 98px;">
                <a href="<?php echo $file; ?>"><span class="glyphicon glyphicon-eye-open"></span><?php echo $file; ?></a></span>
              </td>
              <td valign="top" class="td4">
             
                <FORM action="delete2.php">
                <input id="text" type="text"  name="deleting"  value="<?php echo $file; ?>" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif, margin-left: 2px; width: 108px;border: 0px;" />
                <input type="submit" value="Delete"  style="font-size: 8px; font-family: arial, verdana, helvetica, sans serif, margin-left: 2px; width: 48px;"></FORM>	
				
                
               </td>
              
              </tr><?php }} ?>
                </table> 
       </div>
<button class="btn btn-primary"  type="button" value="button"  style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 98px;"onclick="hideFileView();returnfalse;">CloseManager</button> 

                        </div>
                    </div>
                </div>
            </div>



               
</td></tr>
</table>








