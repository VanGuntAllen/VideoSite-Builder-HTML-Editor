


<!--------------------------------------------------------------
  Function    :  LIST  Form Properties Tag  
  Description :  LIST Form  Properties 
 ----------------------------------------------------------------------> 



<div  id="draggable24">
<div id="content-template"  class="panel panel-default" style="position: absolute; left:580px;top:162px; Z-INDEX: 220; width: 500px; display:none;">

<div class="panel-heading" >
                    ContentTemplate  Properties
                        </div>
          
       <div class="panel-body " style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 10px; ">   
    
  <button id="button1id" name="button1id"  onclick="Buildhtml(this.form,5);return  false;" class="btn btn-danger">Content template#1</button>
    <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,8);return  false;" class="btn btn-success">Content template#2</button>
 
<fieldset>

<!-- Form Name -->
<legend>List Form</legend>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="image">Image</label>
  <div class="controls">
    <input id="list-image" class="form-control"  name="list-image" type="text" value="http://i.ytimg.com/vi/ZKOtE9DOwGE/mqdefault.jpg

" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="timageurl">Image URL</label>
  <div class="controls">
    <input id="timageurl" class="form-control"  name="timageurl" type="text" placeholder="image url" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="link-url">Link url</label>
  <div class="controls">
    <input id="link-url" class="form-control"  name="link-url" type="text" placeholder="Link url" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="link-name">Link</label>
  <div class="controls">
    <input id="link-name" class="form-control"  name="link-name" type="text" value="Claudio Bravo, antes su debut con el Barça en la Liga" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textlead">Text Lead</label>
  <div class="controls">
    <input id="textlead" class="form-control"  name="textlead" type="text" value="Lorem ipsum dolor sit amet, consectetur adipisicing elit." class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Section Heading</label>
  <div class="controls">
    <input id="section-heading" class="form-control"  name="section-heading" type="text" value="Section Heading" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Text Area</label>
  <div class="controls">                     
    <textarea id="list-textarea" class="form-control"  name="list-textarea">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, suscipit, rerum quos facilis repellat architecto commodi officia atque nemo facere eum non illo voluptatem quae delectus odit vel itaque amet.</textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="insert"></label>
  <div class="controls">
   <input  class="form-control" onclick="hideContentTemplate();return  false;"type="submit" value="Close" class="input-xlarge">
   
    
  </div>
</div></div></div></div>


