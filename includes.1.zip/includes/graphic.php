<!-- -----------------------------------------------------------------
  Function    :Set Image graphic field Properties Tag  
  Description : Set Image graphic field Properties Tag 
 ----------------------------------------------------------------------> 
<div  id="draggable27">
 <div class="panel panel-default" style="position: absolute; Z-INDEX: 220;left:351px;top:162px; display:none;" style="position:absolute;background-color:#C0C0C0;background-image:url(http://127.0.0.1/VideoBoxBuilder/);background-repeat:repeat;;background-position:left top;left:351px;top:162px;width:207px;height:85px; border: 2px solid #E68282; border-color: #E68282 #650000 #650000 #9C2828;z-index:200"
id="graphic">	
<div class="panel-heading" >
                        Image Properties
                        </div>
            <div class="panel-body">
		<table  width="480" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 <tr><td style="padding-bottom: 0px; padding-top: 0px;" width="300">
		

<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold; color:#000000;">Insert Image:</span>

 <button type="button" class="btn btn-default"  data-toggle="tooltip"  onclick="AddText(this.form,26);return false;"     title="Picture">
                            <i class="fa fa-picture-o"></i>
                        </button>

<table width="380" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="80">Image URL:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="300">

	<input type="text"  name="image" id="Image" value=""  Placeholder="Image URL"  style="font-size: 10px; width: 100%;">
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;">Alternate Text:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="imageAlt" id="imageAlt" value=""  Placeholder="Alternet Text"   style="font-size: 10px; width: 100%;"></td>

<div align="right" style="padding-top: 5px;">
	 </tr>
</table>


<table width="380" border="0" cellpadding="0" cellspacing="0" style="margin-top: 10px;"><tr><td>


<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="100">Alignment:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="imageAlignment" id="imageAlignment" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="left">Left</option>
	 <option value="right">Right</option>
	 <option value="texttop">Texttop</option>
	 <option value="absmiddle">Absmiddle</option>
	 <option value="baseline">Baseline</option>
	 <option value="absbottom">Absbottom</option>
	 <option value="bottom">Bottom</option>
	 <option value="middle">Middle</option>
	 <option value="top">Top</option>
	</select>
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Border Thickness:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="imageBorder" id="imageBorder" value=""   Placeholder="Border Thickness"  style="font-size: 10px; width: 100%;"></td>
 </tr>
</table>	

</td>
<td width="10">&nbsp;</td>
<td>

<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold; color:#000000;"> Image Layout:</span>
<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="80">ImageWidth:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="imageWidth" id="horizontal" value=""  Placeholder="Image Width"  style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;color:#000000; ">ImageHeight:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="imageHeight" id="vertical" value=""  Placeholder="Image Height"  style="font-size:  10px; width: 100%;"></td>
 </tr>
</table>	
<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold;top:180px; color:#000000;">Div Spacing:</span>
<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;" width="80">Top:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="div_imageTop" id="" value=""  Placeholder="Top"   style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Left :</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="div_imageLeft" id="" value=""  Placeholder="Left"  style="font-size: 10px; width: 100%;"></td>
 </tr>
</table>	
</td></tr></table>


</td></tr></table>	

<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 350px;  margin-top: 10px; width: 52px;" onClick="hideGraphic();return false;">Close</button>

</div></div></div></div>
