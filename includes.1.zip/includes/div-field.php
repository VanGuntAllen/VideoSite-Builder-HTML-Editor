<!-- -----------------------------------------------------------------
  Function    :Set div field Properties Tag  
  Description : Set div field Properties Tag 
 ----------------------------------------------------------------------> 

<div id="draggable2">



<div id="div_field" name="div_field" class="panel panel-default" style="position: absolute;left:40px; top:155px;Z-INDEX: 100;width:600px; display:none;" id="div_field">
	 <div class="panel-heading" >
                        DIV field Properties
                        </div>
            <div class="panel-body">
 
	<span style="font-family: arial, verdana, helvetica; font-size: 9px; font-weight: bold; color:#ffffff;">Insert DIV field:</span>
	<table width="405" border="0" cellpadding="0" cellspacing="0" style="background-color:  border: 2px solid #FFFFFF; padding: 0px;">
<tr>

 <tr><td><input type="submit" value="   div style " onClick="AddText(this.form,33);return false;" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 1px; width: 82px;"  >

 <td><input type="submit" value="  div class  " onClick="AddText(this.form,34);return false;" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 82px;"  >

 <td><input type="submit" value="  div id+class  " onClick="AddText(this.form,35);return false;" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 3px; width: 98px;"  >
<td><input type="submit" value="  div  Layer  " onClick="AddText(this.form,36);return false;" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 3px; width: 98px;"  >

 <td><input type="submit" value="   div image url  " onClick="AddText(this.form,32);return false;" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 4px; width: 81px;"  >

 
 
	<td style="padding-bottom: 2px; padding-top: 0px;" width="5">
	<input type="submit" value="  Close  " onClick="hideDIVfield();return false; " style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 3px; width: 98px;"  >

</tr>
</table>	<P>
<table width="295" border="0" cellpadding="0" cellspacing="0" style="background-color: border: 2px solid #FFFFFF; padding: 1px;">
 
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#ffffff;" width="100%">DIV Image url:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="div_image" id="div_image" value=""  Placeholder="DIV Image URL" style="font-size: 10px; width: 100%;"></td>
 </tr>
 
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#ffffff;" width="100%">DIV width:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="div_width" id="horizontal" value=""   Placeholder="DIV Width"  style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#ffffff;" width="100%">DIV Height:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="div_height" id="div_Heigh" value=""  Placeholder="DIV Height"  style="font-size: 10px; width: 100%;"></td>
 </tr>
 
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff;">DIV id:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="div_id"   Placeholder="DIV id"  value=""  style="font-size: 10px; width: 55%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff;">Style z-index:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="div_style_index" value=""  Placeholder="DIV Style z-Index Number"  style="font-size: 10px; width: 55%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff;" width="80">DIV Class :</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="div_class"  value=""   Placeholder=" DIV Class id"  style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff;">Layer title:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="div_title"  value=""  Placeholder=" DIV Layer Title"  style="font-size: 10px; width: 55%;"></td>
 </tr>
<tr>
<tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#ffffff;" width="100">StylePosition:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="div_position"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="absolute">absolute</option>
	 <option value="relative">relative</option>
	 
	</select>
	
	</td>
 </tr>
 
  <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#ffffff;" width="100">Alignment:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="div_align" id="div_align" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	  <option value="center"> Center</option>
	 <option value="left">Left</option>
	 <option value="right">Right</option>
	 <option value="texttop">Texttop</option>
	 <option value="absmiddle">Absmiddle</option>
	 <option value="baseline">Baseline</option>
	 <option value="absbottom">Absbottom</option>
	 <option value="bottom">Bottom</option>
	 <option value="middle">Middle</option>
	 <option value="top">Top</option>
	</select>
	</td>
 </tr>

	<td style="padding-bottom: 0px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff;" width="100">DIV Text:</td>
	<td style="padding-bottom: 0px; padding-top: 0px;" width="300">
	
	
<textarea name="field"   rows="3" cols="35"></textarea>

	</td>
 </tr>
 <td style="padding-bottom: 0px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff;" width="100">bgColor:</td>
	<td style="padding-bottom: 0px; padding-top: 0px;" width="300">
	<select class="form-control" name="bg_color" id="bg_color" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100px;"> 

							<option value="" selected="selected">-Select Color-</option> 

							<option value=""> -- Standard -- </option>

							<option  value="#FF0000">Red</option> 

							<option value=" #FF6600 ">Orange</option> 

							<option value="#FFFF00">Yellow</option> 

							<option value=" #00FF00">Green</option> 

							<option value="#000000">Black</option> 

							<option value=" #FFFFFF">White</option> 

							<option value=" #0000FF">Blue</option> 

							<option  value="#C0C0C0">Silver</option> 

							<option value="#FF00FF">Magenta</option> 

							<option value=" #00FFFF">Cyan</option> 

							<option  value="  #FFCC00">Gold</option>

							<option value=""> -- Custom -- </option>

							

						</select>
						
	

	</td>
	<td style="padding-bottom: 0px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff;" width="100">SolidColor:</td>
	<td style="padding-bottom: 0px; padding-top: 0px;" width="300">
	<select class="form-control" name="solid_color" id="solid_color" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100px;"> 

							<option value="" selected="selected">-Select Color-</option> 

							<option value=""> -- Standard -- </option>

							<option  value="#FF0000">Red</option> 

							<option value=" #FF6600 ">Orange</option> 

							<option value="#FFFF00">Yellow</option> 

							<option value=" #00FF00">Green</option> 

							<option value="#000000">Black</option> 

							<option value=" #FFFFFF">White</option> 

							<option value=" #0000FF">Blue</option> 

							<option  value="#C0C0C0">Silver</option> 

							<option value="#FF00FF">Magenta</option> 

							<option value=" #00FFFF">Cyan</option> 

							<option  value="  #FFCC00">Gold</option>

							<option value=""> -- Custom -- </option>

							

						</select>
						
	

	</td>
 </tr>
<P></br><br/></br>

 <table border="0" cellpadding="0" cellspacing="0">
	  <tr>
		 <td width="25"></td>
	   <td></td>
		</tr>
	 </table> 
</td>
 </tr>
</table>

<div  style="position: absolute; Z-INDEX: 220;left:351px;top:162px;">
<tr>
  
 </tr>
 </tr>
  </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; "><P style="font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff">Border Color:</p></td>
	<td style="padding-bottom: 2px; padding-top: 0px;">

<P>
 
<input type="text" size="15" id="enterLayerBorderColor" name="" id="enterLayerBorderColor">
<INPUT class="form-control"  id="layerBorderColorPreview">
</td>
 </tr>
 
  <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px; "><P style="font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff">Border Color:</p></td>
	<td style="padding-bottom: 2px; padding-top: 0px;">

<P>
 
<input type="text" size="15" id="enterLayerBorderColor2" name="" id="enterLayerBorderColor2">
<INPUT class="form-control" id="layerBorderColorPreview2">
</td>
 </tr>
	
<INPUT  onClick="showLayerBorderColorMenu();return false;"
style="Z-INDEX: 2; POSITION: absolute; WIDTH: 20px; HEIGHT: 20px; TOP: 31px; LEFT: 211px" 
id=ImageButton1 name=ImageButton7 src="link font_files/backcolor.gif" 
type=image> 
					 
			 
 	
<INPUT  onClick="showLayerBorderColorMenu2();return false;"
style="Z-INDEX: 2; POSITION: absolute; WIDTH: 20px; HEIGHT: 20px; TOP: 140px; LEFT: 211px" 
id=ImageButton1 name=ImageButton7 src="link font_files/backcolor.gif" 
type=image> 	

</div>
</div>	</div>	

<div id="div_field" name="div_field" style="position: absolute;left:40px; top:155px;Z-INDEX: 100;width:600px" id="div_field">

	<table border="0" cellpadding="0" cellspacing="0" style="padding-bottom: 0px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px;" width="50%">
 <tr>
  	<td style="padding-bottom: 2px; padding-top: 0px;">


 


	<td style="padding-bottom: 0px; padding-top: 0px;" width="100%">
	


<div style="position: absolute;  left:700px;  top:140px; display:none;" id="layerBorderColorMenu2">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF;  padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previelayerwBorderColor2('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayeBorderColor2('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBlayerColor2('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor2('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor2('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table>
		
</div>






<div style="position: absolute; left:625px;  top:140px; display:none; " id="layerBorderColorMenu">
			<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:3px;  top:150px;border: 2px solid #FFFFFF;  padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previelayerwBorderColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayeBorderColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewBlayerColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewlayerBorderColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectlayerBorderColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table>
		
</div>

