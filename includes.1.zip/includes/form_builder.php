
<div class="control-group">
  <label class="control-label" for="Insert Content Section">Insert  Form field</label>
  <div class="controls">
    	
<button type="button" class="btn btn-default"  value=" AdvancedButton"onclick="AddformText(this.form,25);return false;"style="font-family: arial, verdana, helvetica; font-size: 10px; color:#000000;width:66 " title="AdvancedButton">Advanced</button>
    	<button type="button" class="btn btn-default" name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;width:45" onclick="AddformText(this.form,15);return false;">Radio</button>

	<button type="button"  class="btn btn-default" name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px; "onclick="AddformText(this.form,8);return false;">Reset</button>
	<button type="button" class="btn btn-default"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;  onclick="AddformText(this.form,10);return false;">Hidden</button>
	<button type="button" class="btn btn-default"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px; width:55"onclick="AddformText(this.form,9);return false;">Image</button>
	<button type="button" class="btn btn-default"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px; width:55" onclick="AddformText(this.form,11);return false;">Input</button>
	<button type="button" class="btn btn-default"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;  width:53" onclick="AddformText(this.form,13);return false;">comments </button>
	<button type="button" class="btn btn-default"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px; width:55" onclick="AddformText(this.form,12);return false;">Enctype</button>

	<button type="button" class="btn btn-default" name="" value=""  style="font-family: arial, verdana, helvetica; font-size: 9px;  width:53" onclick="AddformText(this.form,7);return false;">Submit</button>
	<button type="button" class="btn btn-default" name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;  width:55" onclick="AddformText(this.form,16);return false;">Text</button>
	<button type="button" class="btn btn-default" name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px; width:55" onclick="AddformText(this.form,17);return false;">Button</button>
	<button type="button" class="btn btn-default" name="ta_Name1" value=""style="font-family: arial, verdana, helvetica; font-size: 10px;width:75" onclick="AddformText(this.form,5);return false;">Password</button>

    <button type="button" class="btn btn-default" name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;color:#000000;" onclick="AddformText(this.form,6);return false;">Checkbox</button>
	 
    
	<button type="button" class="btn btn-default" name="" value=""style="font-family: arial, verdana, helvetica; font-size: 8px;width:55 ;color:#000000;"  onclick="AddformText(this.form,4);return false;">TextArea</button>

     </div>
</div>


	
<div class="control-group"  id="">

       <label class="control-label" for="Insert Content Section">Set button , field Color</label>
                             
	<select class="btn btn-primary" name="button2" lass="form-control" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 50%;">
	 <option value="">Not Set button color class </option>
	 <option >----From class ----</option>
	 
	 <option   value="form-control">form-control</option >
     
	 
	 <option >----Normal Buttons----</option>
	 <option type="button" value="btn btn-default">Default</option >
	 <option   value="btn btn-primary">Primary</option >
     <option   value="btn btn-success">Success</option >
     <option   value="btn btn-info">Info</option >
     <option    value="btn btn-warning">Warning</option >
     <option   value="btn btn-danger">Danger</option >
     <option  value="btn btn-link">Link</option >
 <option >----Buttons Size----</option>
 <option   value="btn btn-primary btn-lg">Large button</option >
 <option   value="btn btn-primary">Default</option >
 <option   value="btn btn-primary btn-sm">Small button</option >
 <option   value="btn btn-primary btn-xs">Mini button</option >
<option >----Success Buttons Size----</option>
<option   value="btn btn-success btn-lg">Large button</option >
 <option   value="btn btn-succes">Default</option >
 <option   value="btn btn-success btn-sm">Small button</option >
 <option   value="btn btn-success btn-xs">Mini button</option >
<option >----Info Buttons Size----</option>
<option   value="btn btn-info btn-lg">Large button</option >
 <option   value="btn btn-info">Default</option >
 <option   value="btn btn-info btn-sm">Small button</option >
 <option   value="btn btn-info btn-xs">Mini button</option >
<option >----Warning Buttons Size----</option>
<option   value="btn btn-warning btn-lg">Large button</option >
 <option   value="btn btn-warning">Default</option >
 <option   value="btn btn-warning btn-sm">Small button</option >
 <option   value="btn btn-warning btn-xs">Mini button</option >

<option >----Danger Buttons Size----</option>
<option   value="btn btn-danger btn-lg">Large button</option >
 <option   value="btn btn-danger">Default</option >
 <option   value="btn btn-danger btn-sm">Small button</option >
 <option   value="btn btn-danger btn-xs">Mini button</option >

<option >----Link Buttons Size----</option>
<option   value="btn btn-link btn-lg">Large button</option >
 <option   value="btn btn-link">Default</option >
 <option   value="btn btn-link btn-sm">Small button</option >
 <option   value="btn btn-link btn-xs">Mini button</option >




<option >----Block level Buttons ----</option>
  <option   value="btn btn-primary btn-lg btn-block">Block level button</option>
  <option   value="btn btn-success btn-lg btn-block">Block level button</option>
  <option   value="btn btn-info btn-lg btn-block">Block level button</option>
   <option   value="btn btn-waring btn-lg btn-block">Block level button</option>
    <option   value="btn btn-danger btn-lg btn-block">Block level button</option>
     <option   value="btn btn-link btn-lg btn-block">Block level button</option>
                                        
     <option >----Outline Buttons----</option>
<option type="button" class="btn btn-outline btn-default">Default</option >
	 <option   value="btn btn-outline btn-primary">Primary</option >
     <option   value="btn btn-outline btn-success">Success</option >
     <option   value="btn btn-outline btn-info">Info</option >
     <option    value="btn btn-outline btn-warning">Warning</option >
     <option   value="btn btn-outline btn-danger">Danger</option >
     <option  value="btn btn-outline btn-link">Link</option >
<option >----Outline Buttons Size----</option>
 <option   value="btn btn-outline btn-primary btn-lg">Large button</option >
 <option   value="btn btn-outline btn-primary">Default</option >
 <option   value="btn btn-outline btn-primary btn-sm">Small button</option >
 <option   value="btn btn-outline btn-primary btn-xs">Mini button</option >
<option   value="btn btn-outline btn-primary btn-lg btn-block">Block level button</option>
  
<option >----Success  Outline Buttons Size----</option>
<option   value="btn  Outline btn-outline btn-lg">Large button</option >
 <option   value="btn  Outline btn-outline">Default</option >
 <option   value="btn  Outline btn-outline btn-sm">Small button</option >
 <option   value="btn  btn-outline btn-xs">Mini button</option >
<option >----Info  Outline Buttons Size----</option>
<option   value="btn btn-outline btn-lg">Large button</option >
 <option   value="btn btn-outline">Default</option >
 <option   value="btn btn-outline btn-sm">Small button</option >
 <option   value="btn btn-outline btn-xs">Mini button</option >
<option >----Warning  Outline Buttons Size----</option>
<option   value="btn btn-outline btn-warning btn-lg">Large button</option >
 <option   value="btn btn-outline btn-warning">Default</option >
 <option   value="btn btn-outline btn-warning btn-sm">Small button</option >
 <option   value="btn btn-outline btn-warning btn-xs">Mini button</option >

<option >----Danger  OutlineButtons Size----</option>
<option   value="btn btn-outline btn-danger btn-lg">Large button</option >
 <option   value="btn btn-outline btn-danger">Default</option >
 <option   value="btn btn-outline  btn-danger btn-sm">Small button</option >
 <option   value="btn btn-outline btn-danger btn-xs">Mini button</option >

<option >----Link  Outline Buttons Size----</option>
<option   value="btn btn-outline btn-link btn-lg">Large button</option >
 <option   value="btn btn-outline btn-link">Default</option >
 <option   value="btn btn-outline btn-link btn-sm">Small button</option >
 <option   value="btn btn-outline btn-link btn-xs">Mini button</option >




<option >----Block level Outline Buttons ----</option>
  <option   value="btn btn-outline btn-primary btn-lg btn-block">Block level button</option>
  <option   value="btn btn-outline btn-success btn-lg btn-block">Block level button</option>
  <option   value="btn btn-outline btn-info btn-lg btn-block">Block level button</option>
   <option   value="btn btn-outline btn-waring btn-lg btn-block">Block level button</option>
    <option   value="btn btn-outline btn-danger btn-lg btn-block">Block level button</option>
     <option   value="btn btn-outline btn-link btn-lg btn-block">Block level button</option>
                           
	</select> </div>

	</div>	<div class="control-group">
  <label class="control-label" for="Insert Content Section">Insert Full Form Content</label>
  <div class="controls">
   <button type="button" class="btn btn-info"  value="menu "onclick="AddformText(this.form,22);return false;"style="font-family: arial, verdana, helvetica; font-size: 9px;width:55;color:#ffffff; ">GoMenu </button>
<button type="button"  class="btn btn-info" value="Combobox "onclick="AddformText(this.form,23);return false;"style="font-family: arial, verdana, helvetica; font-size: 9px;width:66;color:#ffffff; ">Combobox </button>

<button type="button" class="btn btn-info"  value="FileUpload"onclick="AddformText(this.form,26);return false;"style="font-family: arial, verdana, helvetica; font-size: 9px;width:66 ">File Upload</button>
	
 
	 <button type="button" class="btn btn-info"  value="  Search  "onclick="AddformText(this.form,19);return false;"style="font-family: arial, verdana, helvetica; font-size: 10px; color:#ffffff; width:86 ">SearchForm</button>
	<button type="button"class="btn btn-info"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;width:54' color:#ffffff; " onclick="AddformText(this.form,20);return false;">mapform</button>
		<button type="button" class="btn btn-info"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;width:77; color:#ffffff;" onclick="AddformText(this.form,18);return false;">commentsForm </button>
		
	<button type="button"class="btn btn-info"  name="" value="" style="font-family: arial, verdana, helvetica; font-size: 9px;width:90; color:#ffffff;" onclick="AddformText(this.form,24);return false;">GoMenuForm </button>

    
     </div>
</div>


	<BR>
<textarea rows="10" cols="32" id="formtext" name="formtext">

</textarea>
<textarea rows="10" cols="27" name="formtext2">

</textarea>


<BR>

		<!-- Text input-->
	<div class="control-group">
  <label class="control-label" for="Insert Content Section"></label>
  <div class="controls">
    <button id="Properties" name="Properties"   onclick="hideFormBuilder();return false;"class="btn btn-info">Close</button>
 	<button id="button1id" name="button1id" onclick="Buildhtml(this.form,20);return  false;" class="btn btn-info">Insert Form in to Page Body </button>
 
 

 
  </div>
</div>
</div></div>




<div class="panel panel-primary"  id="imageproperties" class="imageproperties"  style="position: absolute;left:140px; top:0px; Z-INDEX: 110; display:none;" >
	 <div class="panel-heading" >
                    	Set Image url  :
                        </div>
            <div class="panel-body">




		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Input imageFile:</label>
  <div class="controls">
<input name="input_image" type="text" id="input_image" value="" size="17">
 			
 	
 
  </div>
</div>

		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">input Image alt:</label>
  <div class="controls">

    <input name="input_alt" type="text" id="input_alt" value="" size="17">		
 	
 
  </div>
</div>


		<!-- Text input-->
	<div class="control-group">
  <label class="control-label" for="Insert Content Section">InsertProperties</label>
  <div class="controls">
    <button id="Properties" name="Properties"   onclick="hideImageProperties(this.form,4);return false;" class="btn btn-info">OK</button>
 
 

 
  </div>
</div>
	

</div></div>


<div class="panel panel-primary"  id="prop"  style="position: absolute;left:140px; top:0px; Z-INDEX: 120; display:none;" >
	 <div class="panel-heading" >
                    	Set Input Type  :
                        </div>
            <div class="panel-body">



		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Input Type:</label>
  <div class="controls">
 	<select name="input_type" id="input_type" style="margin-right: 10px; font-size: 10px;">
	 <option value="">Not Set</option>
	 
	
	 <option value="button">button:</option>
	 <option value="checkbox">checkbox:</option>
	 <option value="color">Color:</option>
	<option value="date">Date:</option>
	
	
	<option value="email">Email:</option>
	  <option value="file">file:</option>
	   <option value="hidden">hidden:</option>
	    <option value="hidden">hidden:</option>
	 <option value="number">Number:</option>
	
	 <option value="search">Search:</option>
	  <option value="password">password:</option>
	 
	 <option value="radio">radio:</option>
	<option value="text">text:</option>
	 <option value="url">URL:</option>
	 
	 <option value="reset">reset:</option>
	</select>	
   </div>
</div>
	
	
	

		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Autocomplete:</label>
  <div class="controls">
 	<select name="autocomplete" id="autocomplete" style="margin-right: 10px; font-size: 10px;">
	 <option value="">Not Set</option>
	 <option value="on">On</option>
	 <option value="off">Off </option>
	 
	 
	</select>	
    </div>
</div>



		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Input Name :</label>
  <div class="controls">
<input name="Name3" type="text" id="Name3" value="" size="7">
 
 
 
  </div>
</div>

		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput"> Input value:</label>
  <div class="controls">
 <input name="input_value" type="text" id="input_value" value="" size="7">
   </div>
</div>
	

		<!-- Text input-->
	<div class="control-group">
  <label class="control-label" for="Insert Content Section">InsertProperties</label>
  <div class="controls">
    <button id="Properties" name="Properties"  onclick="hideProp();return false;" class="btn btn-info">OK</button>
 
 

 
  </div>
</div>
	
	
</div></div>


<div class="panel panel-primary" id="textareaproperties" class="textareaproperties" style="position: absolute;left:140px; top:0px;Z-INDEX: 100; display:none;" >
	 <div class="panel-heading" >
                        Set TextArea Properties:
                        </div>
            <div class="panel-body">


		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">TextAreaName :</label>
  <div class="controls">
 
  <input name="Name2" type="text" id="Name2" value="" size="8"style="font-family: arial, verdana, helvetica; font-size: 10px;" >  
  </div>
</div>

		
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">TextArea_ID:</label>
  <div class="controls">
 
  <input name="ta_id" type="text" id="ta_id" value="" size="8"style="font-family: arial, verdana, helvetica; font-size: 10px;" >
    
  </div>
</div>

		
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">TextAreaRows :</label>
  <div class="controls">
   <input name="Name2" type="text" id="ta_Rows1" value="" size="8"style="font-family: arial, verdana, helvetica; font-size: 10px;" >
    
  </div>
</div>

		
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">TextAreaCol:</label>
  <div class="controls">
   <input name="ta_id" type="text" id="ta_Cols1" value="" size="8"style="font-family: arial, verdana, helvetica; font-size: 10px;" >
    
  </div>
</div>
	
	<!-- Text input-->
	<div class="control-group">
  <label class="control-label" for="Insert Content Section">InsertProperties</label>
  <div class="controls">
    <button id="TextAreaProperties" name="TextAreaProperties" onclick="hideTextAreaProperties();return false;"  class="btn btn-info">OK</button>
 
 

 
  </div>
</div>
</div></div>




<div class="panel panel-primary"  id="formproperties" class="formproperties" style="position: absolute;left:140px; top:0px; Z-INDEX: 100; display:none;" >
	 <div class="panel-heading" >
                    Set Form Properties:
                        </div>
            <div class="panel-body">


		
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Form  Method:</label>
  <div class="controls">
  <input name="method" type="text" id="method" value="" size="8" style="font-family: arial, verdana, helvetica; font-size: 10px;" >
  
    
  </div>
</div>
		
		
			
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput"> Action:</label>
  <div class="controls">
  
  <input name="action" type="text" id="action" value="" size="8"style="font-family: arial, verdana, helvetica; font-size: 10px;" >
    
  </div>
</div>
			
			
		
			
		
			
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Autocomplete:</label>
  <div class="controls">
  
  <input name="Name1" type="text" id="autocomplete" value="" size="8"style="font-family: arial, verdana, helvetica; font-size: 10px;" >
    
  </div>
</div>	
		
			
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">FormName :</label>
  <div class="controls">
  <input name="Name1" type="text" id="Name1" value="" size="8"style="font-family: arial, verdana, helvetica; font-size: 10px;" >
  
    
  </div>
</div>
			
	
			
		<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput"> ID:</label>
  <div class="controls">
  
  <input name="fm_id" type="text" id="fm_id" value="" size="7"style="font-family: arial, verdana, helvetica; font-size: 10px;" >
    
  </div>
</div>
   
	<div class="control-group">
  <label class="control-label" for="Insert Content Section">Insert Content</label>
  <div class="controls">
    <button id="FormProperties" name="FormProperties" onclick="hideFormProperties();return false;" class="btn btn-info">OK</button>
 
 	
  </div>
</div>			
	

</div></div></div>