<script src="js/menu-1.js"></script>
 <script src="js/menu-2.js"></script>
   <script src="js/menu-3.js"></script>
    <script src="js/body-temp.js"></script>
     <script src="js/body-temp-1.js"></script>
      <script src="js/body-temp2.js"></script>
       <script src="js/content-section.js"></script>
       <script src="js/footer.js"></script>
       <script src="js/css.js"></script>
       <script src="js/content-list.js"></script>
        <script src="js/audio-bar-player.js"></script>
       <script src="js/form-builder.js"></script>
        <script src="js/carousel.js"></script>
         <script src="js/marquee.js"></script>
      <script src="js/main-function.js"></script>
        <script src="js/main-function1.js"></script>
    <script src="js/form.js"></script>
  <script src="js/draggable.js"></script>  
 <script src="js/printit.js"></script>

 
<script src="resizable.js"></script>  
 


<script src="http://smtvs.com/nyteglow.com_filemanager-1/js/plugins.js"></script>
	<script src="http://smtvs.com/nyteglow.com_filemanager-1/js/jPlayer/jquery.jplayer/jquery.jplayer.js"></script>
	<script src="http://smtvs.com/nyteglow.com_filemanager-1/js/modernizr.custom.js"></script>
		    <script src="http://feather.aviary.com/imaging/v2/editor.js"></script>
	