

 
<div id="draggable" >
<div  id="anchor"  class="panel panel-default" style="position: relative; left:900px;top:0px; display:none; background-color:#F7F7F7;background-image:url(); border: 2px solid #CCCCCC; border-color: #CCCCCC #121212 #121212 #CCCCCC;z-index:40; HEIGHT:350px; width:396px">	


<div class="panel-heading" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 10px; ">
                       Link / Anchor  Buttons /Properties
                        </div>
            <div class="panel-body">

<table  border="0" cellpadding="0" cellspacing="0" style="padding: 10px;"><tr>
<td>
<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold;color:#000000;">Insert Anchor:</span>

	  <button type="button" class="btn btn-default" onclick="AddText(this.form,9);return false;" data-toggle="tooltip" title="Link">
                            <i class="fa fa-link"></i>
                        </button>
   <br>
  
<table width="340" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 <tr>
  <td style="padding-bottom: 2px; width: 50px; font-family: arial, verdana, helvetica; font-size: 11px;">Type:</td>
	<td style="padding-bottom: 2px;">
	<select name="AnchorType" id="linkType" style="margin-right: 10px; font-size: 11px; width: 100%;"">
	 <option value="">Not Set</option>
	 <option value="http://">http:</option>
	 <option value="https://">https:</option>
	  <option value="mailto:">mailto:</option>
	</select>
	</td>	
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" color:#000000; width="100">Alignment:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="alignment"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="left">Left</option>
	 <option value="right">Right</option>
	 <option value="texttop">Texttop</option>
	 <option value="absmiddle">Absmiddle</option>
	 <option value="baseline">Baseline</option>
	 <option value="absbottom">Absbottom</option>
	 <option value="bottom">Bottom</option>
	 <option value="middle">Middle</option>
	 <option value="top">Top</option>
	 
	</select>
	</td>
 </tr>
 <td style="padding-bottom: 2px; width: 50px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;"> ButtonType:</td>
	<td style="padding-bottom: 2px;">
 
 <select  name="button" lass="form-control" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 50%;">
	
 
 
  <option >----Normal Buttons----</option>
	 <option type="button" value="btn btn-default">Default</option >
	 <option   value="btn btn-primary">Primary</option >
     <option   value="btn btn-success">Success</option >
     <option   value="btn btn-info">Info</option >
     <option    value="btn btn-warning">Warning</option >
     <option   value="btn btn-danger">Danger</option >
     <option  value="btn btn-link">Link</option >
 <option >----Primary Buttons Size ----</option>
 <option   value="btn btn-primary btn-lg">Large button</option >
 <option   value="btn btn-primary">Default</option >
 <option   value="btn btn-primary btn-sm">Small button</option >
 <option   value="btn btn-primary btn-xs">Mini button</option >
<option >----Success Buttons Size----</option>
<option   value="btn btn-success btn-lg">Large button</option >
 <option   value="btn btn-succes">Default</option >
 <option   value="btn btn-success btn-sm">Small button</option >
 <option   value="btn btn-success btn-xs">Mini button</option >
<option >----Info Buttons Size----</option>
<option   value="btn btn-info btn-lg">Large button</option >
 <option   value="btn btn-info">Default</option >
 <option   value="btn btn-info btn-sm">Small button</option >
 <option   value="btn btn-info btn-xs">Mini button</option >
<option >----Warning Buttons Size----</option>
<option   value="btn btn-warning btn-lg">Large button</option >
 <option   value="btn btn-warning">Default</option >
 <option   value="btn btn-warning btn-sm">Small button</option >
 <option   value="btn btn-warning btn-xs">Mini button</option >

<option >----Danger Buttons Size----</option>
<option   value="btn btn-danger btn-lg">Large button</option >
 <option   value="btn btn-danger">Default</option >
 <option   value="btn btn-danger btn-sm">Small button</option >
 <option   value="btn btn-danger btn-xs">Mini button</option >

<option >----Link Buttons Size----</option>
<option   value="btn btn-link btn-lg">Large button</option >
 <option   value="btn btn-link">Default</option >
 <option   value="btn btn-link btn-sm">Small button</option >
 <option   value="btn btn-link btn-xs">Mini button</option >




<option >----Block level Buttons ----</option>
  <option   value="btn btn-primary btn-lg btn-block">Block level button</option>
  <option   value="btn btn-success btn-lg btn-block">Block level button</option>
  <option   value="btn btn-info btn-lg btn-block">Block level button</option>
   <option   value="btn btn-waring btn-lg btn-block">Block level button</option>
    <option   value="btn btn-danger btn-lg btn-block">Block level button</option>
     <option   value="btn btn-link btn-lg btn-block">Block level button</option>
                                        
     <option >----Outline Buttons----</option>
<option type="button" class="btn btn-outline btn-default">Default</option >
	 <option   value="btn btn-outline btn-primary">Primary</option >
     <option   value="btn btn-outline btn-success">Success</option >
     <option   value="btn btn-outline btn-info">Info</option >
     <option    value="btn btn-outline btn-warning">Warning</option >
     <option   value="btn btn-outline btn-danger">Danger</option >
     <option  value="btn btn-outline btn-link">Link</option >
<option >----Outline Buttons Size----</option>
 <option   value="btn btn-outline btn-primary btn-lg">Large button</option >
 <option   value="btn btn-outline btn-primary">Default</option >
 <option   value="btn btn-outline btn-primary btn-sm">Small button</option >
 <option   value="btn btn-outline btn-primary btn-xs">Mini button</option >
<option   value="btn btn-outline btn-primary btn-lg btn-block">Block level button</option>
  
<option >----Success  Outline Buttons Size----</option>
<option   value="btn  Outline btn-outline btn-lg">Large button</option >
 <option   value="btn  Outline btn-outline">Default</option >
 <option   value="btn  Outline btn-outline btn-sm">Small button</option >
 <option   value="btn  btn-outline btn-xs">Mini button</option >
<option >----Info  Outline Buttons Size----</option>
<option   value="btn btn-outline btn-lg">Large button</option >
 <option   value="btn btn-outline">Default</option >
 <option   value="btn btn-outline btn-sm">Small button</option >
 <option   value="btn btn-outline btn-xs">Mini button</option >
<option >----Warning  Outline Buttons Size----</option>
<option   value="btn btn-outline btn-warning btn-lg">Large button</option >
 <option   value="btn btn-outline btn-warning">Default</option >
 <option   value="btn btn-outline btn-warning btn-sm">Small button</option >
 <option   value="btn btn-outline btn-warning btn-xs">Mini button</option >

<option >----Danger  OutlineButtons Size----</option>
<option   value="btn btn-outline btn-danger btn-lg">Large button</option >
 <option   value="btn btn-outline btn-danger">Default</option >
 <option   value="btn btn-outline  btn-danger btn-sm">Small button</option >
 <option   value="btn btn-outline btn-danger btn-xs">Mini button</option >

<option >----Link  Outline Buttons Size----</option>
<option   value="btn btn-outline btn-link btn-lg">Large button</option >
 <option   value="btn btn-outline btn-link">Default</option >
 <option   value="btn btn-outline btn-link btn-sm">Small button</option >
 <option   value="btn btn-outline btn-link btn-xs">Mini button</option >




<option >----Block level Outline Buttons ----</option>
   <option   value="btn btn-outline  btn-defaul btn-lg btn-block">Block level defaul  button</option>
  <option   value="btn btn-outline btn-primary btn-lg btn-block">Block level primary button</option>
  <option   value="btn btn-outline btn-success btn-lg btn-block">Block level success button</option>
  <option   value="btn btn-outline btn-info btn-lg btn-block">Block level info button</option>
   <option   value="btn btn-outline btn-waring btn-lg btn-block">Block level Gray button</option>
    <option   value="btn btn-outline btn-danger btn-lg btn-block">Block level daner button</option>
     <option   value="btn btn-outline btn-link btn-lg btn-block">Block level link  button</option>
   
 </select>
	</td>
 </tr>
 
 
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	
	</td>
 </tr>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Anchor Name:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="anchor" id="link" value=""   Placeholder="Anchor URL"  style="font-size: 10px; width: 100%;"></td>
 
 </td>	
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">URL:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="AnchorUrl"  Placeholder="Anchor URL"  id="url" value=""  style="font-size: 10px; width: 100%;"></td>
</tr>

 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	
	             
	
<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 147px; width: 62px;top:0px;" onClick="hideAnchor();return false;">Close</button>

	
</td>
</tr>

</table>	
 </tr>
</table>	
</div></div></div>