     
       <!-- --------------------------------
  Function    :source_code Properties 
  Description : source_code Textarea
 ----------------------------------------------------------------------> 
   
                
                
                 <div  id="PageView" class="panel-body"   style="Z-INDEX: 27; POSITION: absolute; background-color: #F7F7F7;   TOP: 76px; LEFT: 0px">
                
                 <textarea id="" name="body" rows="30" cols="500"  class="form-control"></textarea>
       
                <p>#1.This is the body of the page ,how it work you can insert  in to the body  image ,video ,audio player ,page template frame work and build a page or full site,try it just click on one of the button like the menu in the body Txte Area then click on generate preview then click on the world icon to view web page </p>

              
                
                </div><P>
                <div   id="source_code" class="panel-body"   style=" display:none; ">
                
               
                
                <textarea id="area2" name="file" rows="30" cols="464"  class="form-control"><?php echo $loadfile; ?></textarea>

              
<input  type="text" class="form-control" name="filename" id=data value="<?php echo $fname; ?>" size="30" style="POSITION: absolute;  font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 300px;TOP: 691px; LEFT:14px" />
	
</div>
               
            </div>
        </div>
    </div>
</div>
    	<div  id="draggable15">
<div id="design"  class="panel panel-default" style="Z-INDEX: 27; POSITION: absolute; display:none; background-color: #F7F7F7;font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px;  WIDTH: 1400px; TOP: 170px; LEFT: 20px" >
<div class="panel-heading" >
                        LiveView
                        </div>
                        
                        
<iframe src="about:blank" name="preview" style="height:614px;width:1400px;border:solid 1px #b9b8b6;background:#ffffff" frameborder="0" >
</iframe>
<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 102px;top:200px;" onClick="hideDesign();return false;">Close</button>

</div></div>
