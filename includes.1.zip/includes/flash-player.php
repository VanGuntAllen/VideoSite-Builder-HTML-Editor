 

 <div id="draggable8">
 <div class="panel panel-default" id="fmediaplayer" style="position: absolute; left:351px;top:162px; Z-INDEX: 220; display:none;" style="position:absolute;background-color:#ffffff;background-image:url();background-repeat:repeat;;background-position:left top;left:351px;top:162px;width:207px;height:85px; border: 2px solid #E68282; border-color: #E68282 #650000 #650000 #9C2828;z-index:200">	
<div class="panel-heading" >
                        Flash Player Properties
                        </div>
            <div class="panel-body">
		<table  width="480" border="0" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border: 2px solid #FFFFFF; padding: 0px;">
 <tr><td style="padding-bottom: 0px; padding-top: 0px;" width="300">
	
 

<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold;  color:#000000;">Insert Fl4v Player:</span>
<button type="button" class="btn btn-default" onclick="AddText(this.form,2);return false;"data-toggle="tooltip" title="flash player ">
                            <i class="fa fa-flash"></i>
                        </button>

<BR><BR>

<table width="380" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="80">Flv video URL:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="300">
<input type="Text" name="flashvars_src" id="media" value="http://vga.smtvs.com/videos/BadDayInAfica.flv"  style="font-size: 10px; width: 100%;">

	</td>
 </tr>
 
 <tr>
  
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="80"align="right">swfs URL:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="300">
	<select class="form-control" name="flash_swfs_src" id="flash_swfs_src" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100px;"> 

							<option value="" selected="selected">-Selecte a Skin-</option> 

						
							<option  value="http://vga.smtvs.com/videos/swfs/StrobeMediaPlayback.swf">Skin 1</option> 
	                     
							
						</select>
	 </tr>
 <tr>

	 </tr>
</table>


<table width="380" border="0" cellpadding="0" cellspacing="0" style="margin-top: 10px;"><tr><td>


<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="100">Alignment:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="flash_div_alignment" id="flash_div_alignment" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="left">Left</option>
	 <option value="right">Right</option>
	 <option value="texttop">Texttop</option>
	 <option value="absmiddle">Absmiddle</option>
	 <option value="baseline">Baseline</option>
	 <option value="absbottom">Absbottom</option>
	 <option value="bottom">Bottom</option>
	 <option value="middle">Middle</option>
	 <option value="top">Top</option>
	</select>
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="100">Player Quality:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="flashquality" id="flashvideoquality" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="High">High</option>
	 <option value="Low">Low</option>
	 
	</select>
	</td>
 </tr>
  <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="100">Allowfullscreen:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="fullscreen" id="fullscreen" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="true">True</option>
	 <option value="false">False</option>
	 
	</select>
	</td>
 </tr>
  <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="100">Autoplay:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="flashautoplay" id="flashautoplay" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="true">True</option>
	 <option value="false">False</option>
	 
	</select>
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="100">AutoHideControlBar:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="autoHideControlBar" id="autoHideControlBar" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="true">True</option>
	 <option value="false">False</option>
	 
	</select>
	</td>
 </tr>
 
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px; color:#000000;">Bgcolor:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="flvplayerbgcolor" id="flvplayerbgcolor" value="" Placeholder="Bgcolor" style="font-size: 10px; width: 100%;"></td>
 </tr>
 
</table>	

</td>
<td width="10">&nbsp;</td>
<td>


<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #F7F7F7; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="80">PlayerWidth:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="flashplayer_width" id="horizontal" value=""  Placeholder="Player Eidth"  style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;">PlayerHeight:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="flashplayer_height" id="vertical" value=""   Placeholder="Player Height" style="font-size: 10px; width: 100%;"></td>
 </tr>
</table>	

<table width="185" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;" width="80">Top:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="flashplayer_div_top" id="" value=""  Placeholder="Top"  style="font-size: 10px; width: 100%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;  color:#000000;">Left :</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="flashplayer_div_left" id="" value=""  Placeholder="Left"  style="font-size: 10px; width: 100%;"></td>
 </tr>
</table>

</td></tr></table>
	

</td></tr></table>


<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 350px;  margin-top: 10px; width: 52px;" onClick="hideFMediaPlayer();return false;">Close</button>

</div></div></div>


</div>
