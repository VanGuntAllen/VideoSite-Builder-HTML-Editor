
<!-- --------------------------------
  Function    :PageProperties Tag  
  Description : Page Properties 
 ----------------------------------------------------------------------> 


<div id="draggable5">
<div  class="panel panel-default" style="position: absolute; left:351px;top:162px; Z-INDEX: 210;  display:none;" style="position:absolute;background-color:#C0C0C0;background-image:url();background-repeat:repeat;;background-position:left top;left:351px;top:162px;width:307px;height:85px; border: 2px solid #E68282; border-color: #E68282 #650000 #650000 #9C2828;z-index:200"
id="fontform">
	

<div class="panel-heading" >
                        Text Font Properties
                        </div>
            <div class="panel-body" style="background-color: #ffffff; border: 2px solid #000000; padding: 5px;">
            	
   
<table width="485" border="0" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border: 2px solid #FFFFFF; padding: 5px;">
<tr><td><input class="btn btn-primary btn-sm" type="submit" value="  Insert Text " onClick="AddText(this.form,45);return false;" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 78px;"  >
  <td>
  
  
  </td>
  
	<tr>
	
	<td style="padding-bottom: 0px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100">Text:</td>
	<td style="padding-bottom: 0px; padding-top: 0px;" width="200">
	
	
<textarea class="form-control" name="font" rows="4" cols="22"></textarea>
<BR>
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;">FontColor:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"width="100">
	

<input type="text" size="15" id="enterFontColor" name="fontColor" id="enterFontColor">

 <table border="0" cellpadding="0" cellspacing="0">
	  <tr>
		 <td width="25"><table border="0" cellpadding="0" cellspacing="0"><tr><td style="width: 25px; background-color: #FFFFFF; border: 1px solid #000000; font-size: 10px;" id="FontColorPreview">&nbsp;</td></tr></table></td>
	   <td><button style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 38px;" onClick="showFontColorMenu();return false;">Pick</button></td>
		</tr>
	 </table> 
	  <div style="position: absolute; right: 30px;Z-INDEX: 100; display:none;" id="FontColorMenu">
	 
	<table width="70" border="0" cellpadding="0" cellspacing="0" style="  position:absolute; background-color: #F7F7F7; left:-375px;  top:-100px;border: 2px solid #FFFFFF;  padding: 0px;">
 
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#000000');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#000000');"><div style="background-color: #000000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#993300');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#993300');"><div style="background-color: #993300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#333300');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#333300');"><div style="background-color: #333300;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#003300');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#003300');"><div style="background-color: #003300;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#003366');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#003366');"><div style="background-color: #003366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#000080');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#000080');"><div style="background-color: #000080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#333399');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#333399');"><div style="background-color: #333399;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#333333');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#333333');"><div style="background-color: #333333;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#800000');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#800000');"><div style="background-color: #800000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FF6600');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FF6600');"><div style="background-color: #FF6600;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#808000');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#808000');"><div style="background-color: #808000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#008000');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#008000');"><div style="background-color: #008000;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#008080');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#008080');"><div style="background-color: #008080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#0000FF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#0000FF');"><div style="background-color: #0000FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#666699');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#808080');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#808080');"><div style="background-color: #808080;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FF0000');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FF0000');"><div style="background-color: #FF0000;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FF9900');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FF9900');"><div style="background-color: #FF9900;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#99CC00');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#99CC00');"><div style="background-color: #99CC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#339966');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#339966');"><div style="background-color: #339966;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#33CCCC');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#33CCCC');"><div style="background-color: #33CCCC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#3366FF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#3366FF');"><div style="background-color: #3366FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#800080');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#800080');"><div style="background-color: #800080;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#999999');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#999999');"><div style="background-color: #999999;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FF00FF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FF00FF');"><div style="background-color: #FF00FF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FFCC00');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FFCC00');"><div style="background-color: #FFCC00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FFFF00');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FFFF00');"><div style="background-color: #FFFF00;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#00FF00');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#00FF00');"><div style="background-color: #00FF00;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#00FFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#00FFFF');"><div style="background-color: #00FFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#00CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#00CCFF');"><div style="background-color: #00CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#993366');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#993366');"><div style="background-color: #993366;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#C0C0C0');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#C0C0C0');"><div style="background-color: #C0C0C0;" class="selectColorBox">&nbsp;</div></td>
			 </tr>
			 <tr>
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FF99CC');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FF99CC');"><div style="background-color: #FF99CC;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FFCC99');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FFCC99');"><div style="background-color: #FFCC99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FFFF99');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FFFF99');"><div style="background-color: #FFFF99;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#CCFFCC');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#CCFFCC');"><div style="background-color: #CCFFCC;" class="selectColorBox">&nbsp;</div></td>		 
			  <td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#CCFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#CCFFFF');"><div style="background-color: #CCFFFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#99CCFF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#99CCFF');"><div style="background-color: #99CCFF;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#CC99FF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#666699');"><div style="background-color: #666699;" class="selectColorBox">&nbsp;</div></td>
				<td class="selectColorBorder" onMouseOver="className = 'selectColorOn'; previewFontColor('#FFFFFF');" onMouseOut="className = 'selectColorOff'" onClick="selectFontColor('#FFFFFF');"><div style="background-color: #FFFFFF;" class="selectColorBox">&nbsp;</div></td>
		   </tr>	 
			</table>
			</td>
 </tr>
</table>	



<table width="313" border="0" cellpadding="0" cellspacing="0" >
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100">Fontface:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
<select name="text_face"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 111;">
	 <option value="">Not Set</option>
	 <option value="Arial">Arial</option>
	 <option value="Arial Baltic">Arial Baltic</option>
	 <option value="Arial Black">Arial Black</option>
	 <option value="Arial CE">Arial Black</option>
	 <option value="Arial CYR">Arial CYR</option>
	 <option value="BATAVIA">BATAVIA</option>
	 <option value="Belwe Bd BT">Belwe Bd BT</option>
	 <option value="BatangChe">BatangChe</option>
	 <option value="Belwe Lt BT">Belwe Lt BT</option>
	 <option value="Blade Runner Movie Font">Blade Runner Movie Font</option>
	 <option value="Bookman Old Style">Bookman Old Style</option>
	 <option value="Belwe Cn BT">    Belwe Cn BT</option>
<option value="BrowalliaUPC">   BrowalliaUPC</option>
<option value="Belwe Lt BT">    Belwe Lt BT</option>
<option value="Browallia New">  Browallia New</option>
<option value="CASMIRA">CASMIRA</option>
<option value="Calibri ">   Calibri</option>
<option value="Cambria ">   Cambria</option>
<option value="Clarendon Hv BT "> Clarendon Hv BT</option>
<option value="Candy Round BTN">  Candy Round BTN</option>
<option value="ConcursoItalian BTN">  ConcursoItalian BTN</option>
<option value="Clarendon Lt BT "> Clarendon Lt BT</option>
<option value="Clarendon Blk BT "> Clarendon Blk BT</option>
<option value="Candy Round BTN Lt "> Candy Round BTN Lt</option>
<option value="Candara  Candara"> Candara Candara</option>
<option value="Comic Sans MS">  Comic Sans MS</option>
<option value="Consolas "> Consolas</option>
<option value="Constantia "> Constantia</option>
<option value="Corbel  ">Corbel</option>
<option value="CordiaUPC "> CordiaUPC</option>
<option value="Courier New "> Courier New</option>
<option value="Courier New CE "> Courier New CE</option>
<option value="Courier New CYR "> Courier New CYR</option>
<option value="Courier New TUR ">  Courier New TUR</option>
<option value="DFKai-SB "> DFKai-SB</option>
<option value="DaunPenh "> DaunPenh</option>
<option value="David "> David</option>
<option value="DilleniaUPC">  DilleniaUPC</option>
<option value="DokChampa  ">  DokChampa</option>
<option value="Dotum  ">   Dotum</option>
<option value="DotumChe "> DotumChe</option>
<option value="ELEGANCE">   ELEGANCE</option>
<option value="ELLIS  ">   ELLIS</option>
<option value="EXCESS  "> EXCESS</option>
<option value="Ebrima  "> Ebrima</option>
<option value="English157 BT">   English157 BT</option>
<option value="Estrangelo Edessa ">   Estrangelo Edessa</option>
<option value="EucrosiaUPC  ">  EucrosiaUPC</option>
<option value="Euphemia ">  Euphemia</option>
<option value="FangSong   "> FangSong</option>
<option value="Franklin Gothic Medium ">  Franklin Gothic Medium</option>
<option value="FrankRuehl  "> FrankRuehl</option>
<option value="Freehand575 BT   "> Freehand575 BT</option>
<option value="FreesiaUPC ">     FreesiaUPC</option>
<option value="Freehand521 BT">Freehand521 BT</option>
<option value="GENUINE   ">   GENUINE</option>
<option value="Gabriola  ">   Gabriola</option>
<option value="Galeforce BTN ">   Galeforce BTN</option>
<option value="Gautami  ">  Gautami</option>
<option value="Georgia  ">  Georgia</option>
<option value="Galeforce BTN "> Galeforce BTN</option>
<option value="Gautami  "> Gautami</option>
<option value="GrilledCheese BTN Cn ">   GrilledCheese BTN Cn</option>
<option value="GrilledCheese BTN Toasted "> GrilledCheese BTN Toasted</option>
<option value="GrilledCheese BTN Wide Blk "> GrilledCheese BTN Wide Blk</option>
<option value="Gulim  "> Gulim</option>
<option value="GulimChe ">  GulimChe</option>
<option value="Gungsuh  "> Gungsuh</option>
<option value="HELTERSKELTER ">  HELTERSKELTER
<option value="HERMAN  ">  HERMAN</option>
<option value="Hot Mustard BTN  ">  Hot Mustard BTN</option>
<option value="Hot Mustard BTN Poster ">    Hot Mustard BTN Poster</option>
<option value="ISABELLE  "> ISABELLE</option>
<option value="Impact "> Impact</option>
	</select>
	
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;"></td>
 </tr>
 
</table>	


<table width="303" border="0" cellpadding="0" cellspacing="0" >
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="111">Font Size:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="text_size"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100;">
	 <option value="">Not Set</option>
	 <option value="1">1 </option>
	 <option value="2">2 </option>
	 <option value="3">3 </option>
	 <option value="4">4 </option>
	 <option value="5">5 </option>
	 <option value="6">6 </option>
	 <option value="7">7 </option>
	 <option value="8">8 </option>
	 <option value="9">9 </option>
	 <option value="10">10 </option>
	 <option value="11">11 </option>
	 <option value="12">12 </option>
	 <option value="13">13 </option>
	 <option value="14">14 </option>
	 <option value="15">15 </option>
	 <option value="16">16 </option>
	 <option value="17">17 </option>
	 <option value="18">18 </option>
	 <option value="19">19 </option>
	 <option value="20">20 </option>
	 <option value="21">21 </option>
	 
	</select>
	
	
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;"></td>
 </tr>
 <table width="303" border="0" cellpadding="0" cellspacing="0" >
 
 
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100%">DIV Top:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="div_width" id="" value=""  style="font-size: 10px; width: 170%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100%">DIV Left:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" siz="30" name="div_height" id="" value=""  style="font-size: 10px; width: 170%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100%">DIV Height:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="105">
	<input type="text" name="doucmentHeight" id="" value=""  style="font-size: 10px; width: 170%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100%">DIV width:</td>
	<td style="padding-bottom: 0px; padding-top: 0px;" width="305">
	<input type="text" name="doucmentWidth" id="" value=""  style="font-size: 10px; width: 170;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px;">DIV id:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="div_id"  value=""  style="font-size: 10px; width: 55%;"></td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 10px;">Style z-index:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	<input type="text" name="div_style_index" value=""  style="font-size: 10px; width: 170%;"></td>
 </tr>
 
<tr>
<tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100%">StylePosition:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="div_position"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="absolute">absolute</option>
	 <option value="relative">relative</option>
	 
	</select>
	
	</td>
 </tr>
 
  <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100%">Alignment:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="div_align" id="div_align" style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	  <option value="center"> Center</option>
	 <option value="left">Left</option>
	 <option value="right">Right</option>
	 <option value="texttop">Texttop</option>
	 <option value="absmiddle">Absmiddle</option>
	 <option value="baseline">Baseline</option>
	 <option value="absbottom">Absbottom</option>
	 <option value="bottom">Bottom</option>
	 <option value="middle">Middle</option>
	 <option value="top">Top</option>
	</select>
	</td>
 </tr>

	
	   <td></td>
		</tr>
	 </table> 
</table>
</td>
	<button class="btn btn-primary btn-sm" style=" top:438px;left: 250px; font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 417px; width: 52px;" onClick="hideFontForm();return false;">Close</button>
 
</div>

</div></div></div></div>

