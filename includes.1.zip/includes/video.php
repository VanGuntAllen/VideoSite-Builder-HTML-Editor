<div id="draggable3">
<div id="videoform" class="panel panel-default" style="Z-INDEX: 27; POSITION:  relative; background-color: #F7F7F7; display:none;  TOP: 66px; LEFT: 0px; border: 2px solid #CCCCCC; border-color: #CCCCCC #121212 #121212 #CCCCCC;   TOP: 66px; LEFT: 300px; Width:440px">
 
    <div class="panel-heading" >
                        Video Properties
                        </div>
 <div class="panel-body" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 10px; " >
                        
 	Insert
<button type="button" class="btn btn-default"  onclick="AddText(this.form,15);return false;" data-toggle="tooltip" title="Insert AudioPlayer">
      <i class="fa fa-html5"></i>
                        </button><br/><br/>
<input class="" type="text" name="video" value="Video URL" size="40" /><P>
<input class="" type="text" name="video_poster" value="Image-Poster" size="40" /><P>
<input class="" type="text" name="video_width" value="Player-Width" size="20" /><P>
<input class="" type="text" name="video_height" value="Player-Height" size="20" /><P>

 <div style="Z-INDEX: 210; position: absolute; left:291px;top:50px;width:270px;"><BR>
  <select class="form-control" name="video_filetype"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 50%;">
	 <option value="">MediaType</option>
	 <option value="video/ogg">video ogg</option>
	 <option value="video/mp4">video mp4</option>
	 	 <option value="video/webm">video webm</option>
	 	<option value="audio/ogg">audio ogg</option>
	 	<option value="audio/mpeg">audio mpeg</option>
  </select>
  
  
 <select class="form-control" name="video_audio"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 50%;">
	 <option value="">Audio</option>
	 <option value="muted">Muted</option>
	  <option value="none">none</option>
	
  </select>



 <select class="form-control" name="video_autoplay"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 50%;">
	 <option value="">Autoplay</option>
	 <option value="autoplay">Autoplay</option>
	 <option value="none">none</option>
	 	
  </select>



 <select class="form-control" name="video_loop" i style="font-family: arial, verdana, helvetica; font-size: 11px; width: 50%;">
	 <option value="">Loop</option>
	 <option value="loop">Loop</option>
	 <option value="none">none</option>
  </select>



<select class="form-control" name="video_preload"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 50%;">
	 <option value="">Peload Media</option>
	 <option value="preload">preload</option>
	 <option value="none">none</option>
  </select>

  
 </div>
 <p> <br> <p> <br>
<button class="btn btn-primary" style="   position: absolute; font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 367px; width: 32px;top:9px;" onClick="hideVideoForm();return false;">
 <i class="fa  fa-plus-square"></i>
</button>
     <p> <br>                  
   </div></div></div></div>
         
       

</div>


</div>

