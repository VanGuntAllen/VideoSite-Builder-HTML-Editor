
<!-- --------------------------------
  Function    : Footer  Form Properties Tag  
  Description :  Footer  Form  Properties 
 ----------------------------------------------------------------------> 
<div  id="draggable22">
<div id="footer"  class="panel panel-default" style="position: absolute; left:251px;top:120px; Z-INDEX: 220; width: 500px;display:none;">

<div class="panel-heading" >
                    Footer  Template  Properties
                        </div>
          
       <div class="panel-body " style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 10px; ">   
    


 <button id="button2id" name="button2id"  onclick="Buildhtml(this.form,7);return  false;" class="btn btn-danger">FooterText  template</button>
 


<fieldset>

<!-- Form Name -->
<legend>Footer Text Form </legend>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Text Area</label>
  <div class="controls">                     
    <textarea id="footer-textarea" class="form-control" name="footer-textarea">Copyright &copy; Your Website 2014</textarea>
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebutton"></label>
  <div class="controls">
   <input  class="form-control" onclick="hideFooter();return  false;"type="submit" value="Close" class="input-xlarge">
   
     </div>
</div>

</fieldset>


</div>
</div></div>




