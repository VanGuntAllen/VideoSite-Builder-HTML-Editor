
  $(function() {
    $( "#resizable" ).resizable();
  });
 