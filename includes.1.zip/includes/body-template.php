

<div  id="draggable20" >
 
<div id="body-template" style="Z-INDEX: 27; POSITION: absolute;   TOP: 76px; LEFT: 800px;width: 500px; display:none;">
 
    <div class="row" >
    	<div class="col-md-16">
            <div class="panel with-nav-tabs panel-default">
                <div class="panel-heading"  >
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab1primary" data-toggle="tab"><i class="fa fa-file-image-o"></i>Page Head</a></li>
                            <li><a href="#tab2primary" data-toggle="tab"><i class="fa fa-map-marker"></i> Body Heading 1 & 2</a></li>
                            <li><a href="#tab3primary" data-toggle="tab"><i class="fa fa-file-excel-o"></i>Body Heading 3</a></li>
                        </ul>
                </div>
                <div class="panel-body" >
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab1primary">
                        
                        <!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Image 900x350</label>
  <div class="controls">
    <input id="image-temp" class="form-control" name="image-temp" type="text"  value="http://placehold.it/900x350" placeholder="Image URL" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Heading</label>
  <div class="controls">
    <input id="Heading-temp" class="form-control" name="Heading-temp" type="text"  value="Business Name or Tagline " placeholder="Business Name or Tagline" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Business Text Content </label>
  <div class="controls">                     
    <textarea id="textarea-temp1" class="form-control" name="textarea-temp1">This is a template that is great for small businesses. It doesn't have too much fancy flare to it, but it makes a great use of the standard Bootstrap core components. Feel free to use this template for any project you want!</textarea>
 
 
 
  </div>
</div>
<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Business Text  tagline </label>
  <div class="controls">  
  
   <input id="textarea-tagline" class="form-control" name="textarea-tagline" type="text"  value=" This is a well that is a great spot for a business tagline or phone number for easy access!" placeholder="Image URL" class="input-xlarge">
                     
  
  </div>
</div>
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Call to Action Button Text</label>
  <div class="controls">
    <input id="button-text" class="form-control" name="button-text" type="text"  value="Call to Action!" placeholder="Button Text" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput"> Action Button URL</label>
  <div class="controls">
    <input id="button-url" class="form-control" name="button-url" type="text" placeholder="Button URL" class="input-xlarge">
    
  </div>
</div>
                             </div>
                        
                        
                        
                        <div class="tab-pane fade" id="tab2primary">
                          <!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Heading 1</label>
  <div class="controls">
    <input id="Heading1-temp"class="form-control"  name="Heading1-temp" type="text" placeholder="Heading Text 1" value="Heading1" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Text Content 1</label>
  <div class="controls">                     
    <textarea id="textarea-heading1" class="form-control" name="textarea-heading1">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Saepe rem nisi accusamus error velit animi non ipsa placeat. Recusandae, suscipit, soluta quibusdam accusamus a veniam quaerat eveniet eligendi dolor consectetur.</textarea>
  </div>
</div>

<!-- Password input-->
<div class="control-group">
  <label class="control-label" for="input">More Info URL 1</label>
  <div class="controls">
    <input id="moreinfo-url1" class="form-control" name="moreinfo-url1" type="text" placeholder="More Info URL 1" class="input-xlarge">
    
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Heading 2</label>
  <div class="controls">
    <input id="Heading2-temp" class="form-control" name="Heading2-temp" type="text" placeholder="Heading Text2"  value="Heading2" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Text Content 2</label>
  <div class="controls">                     
    <textarea id="textarea-heading2"class="form-control"  name="textarea-heading2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Saepe rem nisi accusamus error velit animi non ipsa placeat. Recusandae, suscipit, soluta quibusdam accusamus a veniam quaerat eveniet eligendi dolor consectetur.</textarea>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">More Info URL 2</label>
  <div class="controls">
    <input id="moreinfo-url2"class="form-control" name="moreinfo-url2" type="text" placeholder="More Info URL" class="input-xlarge">
    
  </div>
</div>

                        </div>
                        
                        
                        
                        <div class="tab-pane fade" id="tab3primary">

                    
                    
<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">Heading 3</label>
  <div class="controls">
    <input id="Heading3-temp"  class="form-control" name="Heading3-temp" type="text" placeholder="Heading 3 Text" value="Heading3" class="input-xlarge">
    
  </div>
</div>

<!-- Textarea -->
<div class="control-group">
  <label class="control-label" for="textarea">Text Content 3</label>
  <div class="controls">                     
    <textarea id="textarea-heading3"  class="form-control" name="textarea-heading3">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Saepe rem nisi accusamus error velit animi non ipsa placeat. Recusandae, suscipit, soluta quibusdam accusamus a veniam quaerat eveniet eligendi dolor consectetur.</textarea>
  </div>
</div>

<!-- Text input-->
<div class="control-group">
  <label class="control-label" for="textinput">More Info URL 3</label>
  <div class="controls">
    <input id="moreinfo-url3"  class="form-control" name="moreinfo-url3" type="text" placeholder="More Info URL 3" class="input-xlarge">
    
  </div>
</div>

<!-- Button -->
<div class="control-group">
  <label class="control-label" for="singlebutton"></label>
  <div class="controls">
  
   
  </div>
</div>
                    
            
                        </div> 
                        </div>
        
             
                       <button id="button1id" name="button1id"  onclick="Buildhtml(this.form,3);return  false;" class="btn btn-default">Page Body Template#1</button><P><br/>
    <input  class="form-control" onclick="hideBodyTemplate();return  false;"type="submit" value="Close" class="input-xlarge">
         
                    </div>
                </div>
            </div>
        </div>
	</div>



</div>



